"""Equilibrium inference and independent dynamics for a two-coordinate model."""
from pathlib import Path
import json
import numpy as np
from scipy.integrate import quad
from scipy.linalg import eigh
root=Path(__file__).resolve().parents[1]
K=k=2.; lam=.6; m=1.; M=.01; theta=1.
B=np.array([[K,lam],[lam,k]])
Sigma=theta*np.linalg.inv(B)
G=np.linalg.inv(Sigma)
assert np.allclose(theta*G,B,atol=1e-13)
noise=np.array([[.04,.015],[.015,.03]])
observed=Sigma+noise
recovered=theta*np.linalg.inv(observed-noise)
naive=theta*np.linalg.inv(observed)
assert np.allclose(recovered,B,atol=1e-13)
# Known additive noise uncertainty with operator norm at most epsilon.
epsilon=.005
smin=np.linalg.eigvalsh(Sigma)[0]
bound=theta*epsilon/(smin*(smin-epsilon))
interval=[lam-bound,lam+bound]
assert interval[0]>0
rng=np.random.default_rng(20261004)
max_error=0.
for _ in range(500):
 delta=rng.normal(size=(2,2));delta=(delta+delta.T)/2
 delta*=epsilon*rng.random()/np.linalg.norm(delta,2)
 inferred=theta*np.linalg.inv(Sigma+delta)
 err=np.linalg.norm(inferred-B,2)
 assert err<=bound*(1+1e-12)
 max_error=max(max_error,float(err))
Meff=m+lam**2*M/k**2; Keff=K-lam**2/k
freq=np.sqrt(eigh(B,np.diag([m,M]),eigvals_only=True))
low=np.sqrt(Keff/Meff)
assert abs(low/freq[0]-1)<1e-5
# Exact susceptibility after eliminating the second coordinate.
for w in [.1,.5,1.]:
 full=np.linalg.inv(B-w*w*np.diag([m,M]))[0,0]
 schur=1/(K-m*w*w-lam*lam/(k-M*w*w))
 assert np.allclose(full,schur,rtol=1e-12)
# Coupling sign is visible in the cross covariance; frequencies alone do not fix it.
Bminus=np.array([[K,-lam],[-lam,k]])
assert np.allclose(eigh(Bminus,np.diag([m,M]),eigvals_only=True),freq**2)
assert np.sign(np.linalg.inv(Bminus)[0,1])==-np.sign(Sigma[0,1])
# Standard plus residual coupling: induced inertia need not increase.
reference=.6; residual=-.1
mass_residual=M*((reference+residual)**2-reference**2)/k**2
assert mass_residual<0
assert np.isclose(M*((reference-2*reference)**2-reference**2)/k**2,0.)
# Nonquadratic confinement: location Fisher information is beta*mean Hessian.
a=.5; beta=1/theta
U=lambda x:K*x*x/2+a*x**4/4
weight=lambda x:np.exp(-beta*U(x))
Z=quad(weight,-np.inf,np.inf,epsabs=1e-12)[0]
var=quad(lambda x:x*x*weight(x),-np.inf,np.inf,epsabs=1e-12)[0]/Z
fisher=beta**2*quad(lambda x:(K*x+a*x**3)**2*weight(x),-np.inf,np.inf,epsabs=1e-12)[0]/Z
hessian=beta*(K+3*a*var)
assert abs(fisher-hessian)<1e-10
assert abs(fisher-1/var)>1e-3
# Pure readout geometry with fixed unit noise is identical for different B.
readout_metric=np.eye(2)
for l in [0.,.6,-.6]:
 assert np.linalg.eigvalsh(np.array([[2.,l],[l,2.]])).min()>0
 assert np.array_equal(np.linalg.inv(np.eye(2)),readout_metric)
# Quantum pure Gaussian covariance and a fixed-state, variable-frequency family.
Dm=np.diag([m,M]); R=np.diag(1/np.sqrt(np.diag(Dm)))
v2,V=eigh(R@B@R)
Omega=(V*np.sqrt(v2))@V.T
X=.5*R@np.linalg.inv(Omega)@R  # hbar=1
GQ=np.linalg.inv(X)
quantum_reconstruction=.25*GQ@np.linalg.inv(Dm)@GQ
assert np.allclose(quantum_reconstruction,B,atol=1e-12)
c=2.
R2=R/np.sqrt(c); v22,V2=eigh(R2@(B/c)@R2)
Omega2=(V2*np.sqrt(v22))@V2.T
X2=.5*R2@np.linalg.inv(Omega2)@R2
assert np.allclose(X2,X,atol=1e-12)
assert np.allclose(np.sqrt(v22),np.sqrt(v2)/c,atol=1e-12)
result={
 'quantum_position_covariance':X.tolist(),'quantum_reconstructed_coupling':float(quantum_reconstruction[0,1]),'fixed_state_frequency_ratio':float(np.sqrt(v22[0]/v2[0])),
 'inputs_dimensionless':{'K':K,'k':k,'lambda':lam,'m':m,'M':M,'kBT':theta},
 'intrinsic_covariance':Sigma.tolist(),'location_fisher':G.tolist(),
 'known_noise_reconstruction_max_error':float(np.max(np.abs(recovered-B))),
 'uncorrected_noise_lambda':float(naive[0,1]),
 'noise_uncertainty_norm':epsilon,'coupling_error_bound':bound,'coupling_interval':interval,
 'sampled_inverse_error_max_500':max_error,
 'effective_stiffness':Keff,'induced_mass':Meff-m,
 'induced_mass_interval_known_k_M':[M*interval[0]**2/k**2,M*interval[1]**2/k**2],
 'exact_frequencies':freq.tolist(),'low_frequency_approximation':low,
 'relative_low_frequency_error':float(abs(low/freq[0]-1)),
 'quartic_location_fisher':fisher,'quartic_beta_mean_hessian':hessian,'quartic_inverse_variance':1/var,
 'nonzero_extra_coupling_negative_mass_residual':mass_residual,
 'interpretation':'Conditional equilibrium calibration and conservative dynamics; dimensionless synthetic example, not a DG-specific prediction.'}
(root/'results/equilibrium_bridge.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
