"""Deterministic analytical and numerical checks for energetic response.
Run from any directory. No external network or private data required.
"""
from pathlib import Path
import json, platform, csv
import numpy as np
import scipy
from scipy.integrate import solve_ivp
import sympy as sp
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results'; OUT.mkdir(exist_ok=True)
r={"python":platform.python_version(),"numpy":np.__version__,"scipy":scipy.__version__,"sympy":sp.__version__}
# Complex Hermitian controls: column A[n,0] is essential for v.
rng=np.random.default_rng(20260928)
lo3=lo4=float('inf'); phase_err=0.; signed_margin=lo4
for i in range(200):
 d=rng.uniform(.5,3,3); cs=[]
 for _ in range(3):
  z=rng.standard_normal((4,4))+1j*rng.standard_normal((4,4)); cs.append((z+z.conj().T)/2)
 rows=np.array([a[0,1:] for a in cs]); g=np.real((rows/d**2)@rows.conj().T); M=2*np.real((rows/d)@rows.conj().T)
 lo3=min(lo3,np.linalg.eigvalsh(M-2*d.min()*g).min(),np.linalg.eigvalsh(2*d.max()*g-M).min())
 a=cs[0]; v=a[1:,0]/d; B=a[1:,1:]-a[0,0]*np.eye(3); L=max(abs(np.linalg.eigvalsh(B)))
 F=6*np.vdot(v,B@v).real; gs=np.vdot(v,v).real
 lo4=min(lo4,6*L*gs-abs(F))
 # Deterministic eigenbasis phase transformation without consuming RNG stream.
 D=np.diag(np.exp(1j*np.arange(4)*.731)); ap=D.conj().T@a@D
 vp=ap[1:,0]/d; Bp=ap[1:,1:]-ap[0,0]*np.eye(3)
 phase_err=max(phase_err,abs(F-6*np.vdot(vp,Bp@vp).real))
assert lo3>-1e-12 and lo4>-1e-12 and phase_err<1e-10
r['random_bounds']={'seed':20260928,'samples':200,'min_matrix_margin':float(lo3),'min_nonlinear_margin':float(lo4),'max_basis_phase_error':float(phase_err)}
# Symbolic two-level derivative, stable float64 formula after subtracting E0(0)+q E0'(0).
q,a,delta,d=sp.symbols('q a delta d',real=True,positive=True)
E=(-delta-d*q-sp.sqrt((delta+d*q)**2+4*a*a*q*q))/2
assert sp.simplify(sp.diff(E,q,3).subs(q,0)-6*a*a*d/delta**2)==0
errs=[]
for dd in [-1,0,1]:
 x=np.linspace(-1,1,101); qq=x*1e-3; y=-2*.3**2*qq**2/(2+dd*qq+np.sqrt((2+dd*qq)**2+4*.3**2*qq**2))
 fit=np.polynomial.polynomial.polyfit(x,y,5); derivative=6*fit[3]/1e-9
 errs.append(abs(derivative-.135*dd))
r['two_level']={'stable_float64_max_cubic_error':max(errs),'exact_derivatives':[-.135,0,.135]}
assert max(errs)<1e-10
# Finite gap network.
inc=np.array([[-1,1,0,0,0],[0,-1,1,0,0],[0,0,0,-1,1]])
r['gap_graph']={'rank':int(np.linalg.matrix_rank(inc)),'nullity':5-int(np.linalg.matrix_rank(inc))}; assert r['gap_graph']['nullity']==2
# Profiled information and independent calibration.
x=np.linspace(0,1,41)
def info(s,B): return float(np.linalg.norm(s-B@np.linalg.lstsq(B,s,rcond=None)[0])**2)
r['fisher']={'linear_offset':info(x,np.ones((41,1))),'linear_offset_slope':info(x,np.column_stack([x*0+1,x])),'quadratic_offset_slope':info(x*x,np.column_stack([x*0+1,x])),'quadratic_with_quadratic_nuisance':info(x*x,np.column_stack([x*0+1,x,x*x]))}
assert abs(r['fisher']['quadratic_offset_slope']-.2506765625)<1e-12
# Exact spectral moment identity, finite-size source extract arithmetic only.
rr,rho=sp.symbols('r rho',positive=True)
ex=sp.factor((1+rr)*(1+rr/rho**2)/(1+rr/rho)**2-1)
assert sp.simplify(ex-rr*(rho-1)**2/(rho+rr)**2)==0
raw=np.loadtxt(ROOT/'data/wang_yang_2023_fig3a_nu2-7_8e_coulomb.csv',delimiter=',',skiprows=1)
w1=raw[raw[:,0]<2.90,1].sum(); w2=raw[(raw[:,0]>=2.90)&(raw[:,0]<2.935),1].sum(); tail=raw[raw[:,0]>=2.935,1].sum()
excess=lambda r,p:r*(p-1)**2/(p+r)**2
r['spectral_moments']={'w1':float(w1),'w2':float(w2),'tail':float(tail),'r':float(w2/w1),'mixed_input_rho':2.8,'mixed_input_excess':float(excess(w2/w1,2.8)),'illustrative_005_30_excess':float(excess(.05,30)),'interpretation':'Conditional arithmetic, not a measured susceptibility or a new-physics residual.'}
# Classical matrix example: same eigenvectors and gaps, different force.
a0=np.array([[2.,.3],[.3,1.]])
p=np.array([1.,0.]); delta_force=.5*np.dot(p,p)*.4
r['classical']={'scalar_identity_force_shift_fixed_current':delta_force}
# Dynamical storage example, model fully specified and conventional.
m=1.; M=1.; K=4.; k=25.; lam=3.
omsq=np.linalg.eigvalsh(np.array([[K,lam],[lam,k]])); keff=K-lam**2/k; meff=m+lam**2*M/k**2
r['oscillators']={'exact_low_angular_frequency':float(np.sqrt(omsq[0])),'low_frequency_approx':float(np.sqrt(keff/meff)),'effective_stiffness':keff,'effective_mass':meff,'antiresonance_angular_frequency':float(np.sqrt(k/M))}
# Fixed and chirped pumping.
eps=.1; J0=.001
bound=lambda b:(eps+np.sqrt(eps**2+b*b*J0*J0))/b
r['pumping']={'b02_bound':bound(.2),'b08_bound':bound(.8),'chirped_J_t30':J0*np.exp(2*eps*30)}
for bb in [.2,.8]:
 def rhs(t,z):
  J,ph=z; return [-2*eps*J*np.sin(2*ph),bb*J-eps*np.cos(2*ph)]
 sol=solve_ivp(rhs,[0,200],[J0,-np.pi/4],rtol=1e-10,atol=1e-12,max_step=.04)
 assert sol.y[0].max()<=bound(bb)+1e-7
# TF chain with specified (not inferred universal) scattering length.
hbar=1.054571817e-34; mass=86.909180527*1.66053906660e-27; scat=5.8e-9; n0=1e20; omega=2*np.pi*100
gint=4*np.pi*hbar*hbar*scat/mass; mu=gint*n0; R=np.sqrt(2*mu/(mass*omega**2)); N=8*np.pi/15*n0*R**3; Mb=3/7*mass*N*R**2
r['tf']={'a_s_nm':5.8,'R_um':R*1e6,'xi_um':1/np.sqrt(8*np.pi*n0*scat)*1e6,'N':N,'mu_over_hw':mu/(hbar*omega),'Mb_kg_m2':Mb,'abs_Ethird_over_hw':20*Mb*omega/hbar,'conditional_shift_Hz_if_mass_fraction_00014':-.5*.0014*np.sqrt(5)*100}
# The nonlinear bound needs tail block norms, not merely small metric tail.
v=np.array([np.sqrt(.999),np.sqrt(.001)]); B=np.diag([0.,1e6]); r['tail_counterexample']={'tail_weight':.001,'response_quadratic_form':float(v@B@v),'retained_block_norm':0.}
# Pulse model for excitation relative to final instantaneous ground state.
D=np.array([.225,.63]); h=.6582119569; weights=np.array([.5628,.4258]); tau=np.linspace(3.,22.,81)
def design(tr):
 if tr==0: filt=np.sinc(tau[:,None]*D[None,:]/(2*np.pi*h))**2
 else: filt=np.sinc((tau[:,None]-tr)*D/(2*np.pi*h))**2*np.sinc(tr*D/(2*np.pi*h))**2
 return filt/D**2
truth=design(1.)@weights; fit=np.linalg.lstsq(design(0),truth,rcond=None)[0]; right=np.linalg.lstsq(design(1),truth,rcond=None)[0]
r['pulse']={'fit_taus_ps':[3.,22.],'count':81,'true_rise_ps':1.,'wrong_model_weights':fit.tolist(),'correct_model_weights':right.tolist(),'wrong_model_relative_bias_g':float((fit/D**2).sum()/(weights/D**2).sum()-1),'wrong_model_relative_bias_S4':float((fit/D**4).sum()/(weights/D**4).sum()-1),'condition_number_ideal':float(np.linalg.cond(design(0))),'slow_mode_period_ps':float(2*np.pi*h/D[0]),'fast_mode_period_ps':float(2*np.pi*h/D[1]),'lorentzian_T2_ps_if_homogeneous_FWHM003':2*h/.03}
assert np.allclose(right,weights,rtol=1e-11)
(OUT/'response_checks.json').write_text(json.dumps(r,indent=2))
print(json.dumps(r,indent=2))
