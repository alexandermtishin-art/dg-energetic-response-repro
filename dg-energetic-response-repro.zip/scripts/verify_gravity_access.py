import sympy as s
import numpy as np
from scipy.linalg import eigh
import json
from pathlib import Path
q,x,g,m,w,t,a=s.symbols('q x g m w t a', positive=True)
z=s.symbols('z',real=True)
V=m*w*w*z*z/2+m*g*z
assert s.simplify(V.subs(z,q-g/w**2)-(m*w*w*q*q/2-m*g*g/(2*w*w)))==0
J=s.Matrix([[4*(a+t),a+t],[2*(a-2*t),3*(a-2*t)]])
fast=(7*a-2*t+s.sqrt(9*a*a+12*a*t+84*t*t))/2
assert s.simplify((J-fast*s.eye(2)).det())==0
series=s.series(fast,t,0,3).removeO()
assert s.simplify(series-(5*a+s.Rational(20,3)*t*t/a))==0
# General trace perturbation of the isotropic TF breathing eigenvalue.
t1,t2,t3=s.symbols('t1 t2 t3')
A=s.diag(t1,t2,t3)*2+s.Matrix([t1,t2,t3])*s.ones(1,3)
assert s.simplify((s.ones(1,3)*A*s.ones(3,1))[0]/3-s.Rational(5,3)*(t1+t2+t3))==0
K,k,lam,M,om=s.symbols('K k lam M om',positive=True)
D=s.Matrix([[K-m*om**2,lam],[lam,k-M*om**2]])
inv=s.simplify(D.inv()[0,0]);schur=K-m*om**2-lam**2/(k-M*om**2)
assert s.simplify(inv-1/schur)==0
assert s.simplify(s.series(schur,om,0,4).removeO()-(K-lam**2/k-(m+lam**2*M/k**2)*om**2))==0
# A passive change in record noise does not change the already acquired trajectory.
Q=np.array([[2.,.6],[.6,2.]])
e0=eigh(Q,np.diag([1.,.01]),eigvals_only=True)
for sigma in [.1,1.,10.]:
 metric=1/sigma**2
 assert metric>0 and np.allclose(e0,eigh(Q,np.diag([1.,.01]),eigvals_only=True))
grav=9.81;radius=6.371e6;ftrap=100.;wtrap=2*np.pi*ftrap
tide=grav/radius;ratio=tide/wtrap**2
# All symmetric linear response tensors invariant under spatial rotations.
c11,c12,c13,c22,c23,c33=s.symbols('c11 c12 c13 c22 c23 c33')
C=s.Matrix([[c11,c12,c13],[c12,c22,c23],[c13,c23,c33]])
rot=[s.Matrix([[0,0,0],[0,0,-1],[0,1,0]]),s.Matrix([[0,0,1],[0,0,0],[-1,0,0]]),s.Matrix([[0,-1,0],[1,0,0],[0,0,0]])]
solution=s.linsolve([e for L in rot for e in C*L-L*C],(c11,c12,c13,c22,c23,c33))
assert solution==s.FiniteSet((c33,0,0,c33,0,c33))
out={'rotation_invariant_response_tensors':str(solution),'assumptions':['Newtonian external potential at quadratic order','harmonic trap','translation-invariant interatomic interactions','isotropic reference trap for mode formulas','repulsive hydrodynamic Thomas–Fermi limit','no new DG coupling assumed'],
 'uniform_gravity_equilibrium_shift_m':-grav/wtrap**2,
 'isotropic_tide_breathing_to_dipole_ratio':float(np.sqrt(5)),
 'trace_free_tide_breathing_squared_frequency_series':str(series),
 'illustrative_earth_tangential_tide_s-2':tide,
 'trace_free_tide_first_order_breathing_shift':0.,
 'radial_ratio_shift_first_order':np.sqrt(5)*ratio,
 'equivalent_ratio_signal_Hz_at_100Hz':100*np.sqrt(5)*ratio,
 'equivalent_ratio_signal_mHz_at_100Hz':1e5*np.sqrt(5)*ratio,
 'eliminated_coordinate_inverse_susceptibility':str(schur),
 'interpretation':'Reference-model controls, not DG residuals. An apparatus coupling is a physical input; postprocessing distinguishability is not one.'}
dest=Path(__file__).resolve().parents[1]/'results/gravity_access_controls.json'
dest.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
