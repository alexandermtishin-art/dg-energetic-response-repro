import sympy as s
import numpy as np
from scipy.linalg import eigh
from pathlib import Path
import json
a,c=s.symbols('a c',positive=True)
D=s.sqrt(16*a*a-16*a*c+9*c*c)
F=2*a+s.Rational(3,2)*c+D/2
A=s.simplify(s.diff(F,c)-s.diff(F,a)/2)
assert s.simplify(A-(s.Rational(1,2)+(s.Rational(13,2)*c-8*a)/D))==0
assert s.simplify(A.subs(c,a))==0
assert s.simplify(16*a*a-16*a*c+9*c*c-(9*(c-s.Rational(8,9)*a)**2+s.Rational(80,9)*a*a))==0
ff=s.lambdify((a,c),F,'numpy'); aa=s.lambdify((a,c),A,'numpy')
g=9.81;radius=6.371e6;t=g/radius;omega=2*np.pi*100;a0=omega**2
rows=[]
for aspect in [.5,1.,2.]:
 cc=a0*aspect**2; f2=float(ff(a0,cc)); coef=0. if aspect==1. else float(aa(a0,cc))
 f=np.sqrt(f2)/(2*np.pi)
 delta=-3*t*coef/(4*np.pi*np.sqrt(f2))
 rows.append({'aspect_wz_over_wr':aspect,'breathing_like_f_Hz':f,'orientation_coefficient':coef,'parallel_minus_perpendicular_shift_Hz':delta,'shift_mHz':delta*1000})
# Numerical directional derivatives at an amplified tide to avoid cancellation.
C=2*np.eye(3)+np.ones((3,3));val,V=eigh(C);Cs=(V*np.sqrt(val))@V.T
rng=np.random.default_rng(20261004)
errors=[]
for aspect in [.5,1.,2.]:
 base=np.diag([1.,1.,aspect**2]); eps=1e-6
 for angle in [.0,.31,.79,1.2,np.pi/2]:
  n=np.array([np.sin(angle),0.,np.cos(angle)])
  T=np.eye(3)-3*np.outer(n,n)
  def high(sign):
   trap=eigh(base+sign*eps*T,eigvals_only=True)
   return eigh(Cs@np.diag(trap)@Cs,eigvals_only=True)[-1]
  diff=(high(1)-high(-1))/(2*eps)
  expected=float(aa(1.,aspect**2))*(1-3*np.cos(angle)**2)
  err=abs(diff-expected);errors.append(err);assert err<2e-8
# Finite relative bound for all three scaling branches, including degeneracy.
margin=1.
for _ in range(500):
 vals=np.exp(rng.uniform(-2,2,3)); W=np.diag(vals)
 T=rng.normal(size=(3,3));T=(T+T.T)/2
 T-=np.trace(T)*np.eye(3)/3
 T*=.1*vals.min()/np.linalg.norm(T,2)
 epsilon=np.linalg.norm(T,2)/vals.min()
 d=eigh(W,eigvals_only=True);dt=eigh(W+T,eigvals_only=True)
 e=eigh(Cs@np.diag(d)@Cs,eigvals_only=True)
 et=eigh(Cs@np.diag(dt)@Cs,eigvals_only=True)
 lo=(1-epsilon)*e;hi=(1+epsilon)*e
 assert np.all(et>=lo-1e-12) and np.all(et<=hi+1e-12)
 margin=min(margin,float(np.min(np.minimum(et-lo,hi-et)/e)))
out={'model':'Repulsive Thomas-Fermi hydrodynamic scaling modes; external quadratic gravity; fixed trap parameters',
 'inputs':{'g_m_s2':g,'source_radius_m':radius,'radial_trap_Hz':100.},
 'orientation_examples':rows,'max_directional_derivative_error':max(errors),
 'finite_bound_samples':500,'minimum_relative_bound_margin':margin,
 'epsilon_at_min_trap_100Hz':2*t/a0,
 'relative_frequency_shift_bound_first_order':t/a0,
 'interpretation':'Anisotropy permits a standard orientation response; no DG-specific coefficient is derived.'}
dest=Path(__file__).resolve().parents[1]/'results/orientation_bounds.json'
dest.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
