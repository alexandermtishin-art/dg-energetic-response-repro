from pathlib import Path
import json,math
import sympy as s
r,p=s.symbols('r p',positive=True)
S0=1+r;S2=1+r/p**2;S4=1+r/p**4
E4=s.factor(S4*S0/S2**2-1)
assert s.simplify(E4-r*(p**2-1)**2/(p**2+r)**2)==0
rv=0.7566781756227755;pv=2.8
fourth=float(E4.subs({r:rv,p:pv}))
second=rv*(pv-1)**2/(pv+rv)**2
q,m,h,k,O=s.symbols('q m h k O',positive=True)
ER=h*h*k*k/(2*m)
lower=q*q/(2*m)+ER-s.sqrt((h*k*q/m)**2+(h*O/2)**2)
curvature=s.simplify(s.diff(lower,q,2).subs(q,0))
assert s.simplify(curvature-(1-4*ER/(h*O))/m)==0
assert s.simplify((1/(m*curvature)).subs(O,8*ER/h))==2
relative=.0015/(math.sqrt(5)*100)
result={'fourth_moment_excess':fourth,'second_moment_excess':second,'SOC_single_particle_mass_ratio_at_hbarOmega_8ER':2,'target_relative_frequency':relative,'target_abs_inertia_fraction_if_stiffness_fixed':2*relative,'interpretation':'Conditional model arithmetic and target conversion; not a nonzero DG residual.'}
(Path(__file__).resolve().parents[1]/'results/moment_checks.json').write_text(json.dumps(result,indent=2))
print(result)
