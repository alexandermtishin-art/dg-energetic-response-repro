"""Stationary radial GP by normalized Newton solve; projected stable BdG spectrum.
Dimensionless oscillator units; full details and residuals saved to JSON.
No inference of a new force law from mode projections.
"""
from pathlib import Path
import json, numpy as np
from scipy.sparse import diags,bmat,csc_matrix
from scipy.sparse.linalg import spsolve
from scipy.linalg import null_space,eigh
hbar=1.054571817e-34; m=86.909180527*1.66053906660e-27; a=5.8e-9; omega=2*np.pi*100; n0=1e20
aho=np.sqrt(hbar/(m*omega)); gint=4*np.pi*hbar*hbar*a/m; muTF=gint*n0/(hbar*omega); RTF=np.sqrt(2*muTF); Nat=8*np.pi/15*n0*(RTF*aho)**3
out=[]
for cells in [250,500,750]:
 dr=3.2*RTF/cells; r=(np.arange(cells)+.5)*dr; diag=np.full(cells,1/dr**2); diag[0]=1.5/dr**2
 T=diags([-.5*np.ones(cells-1)/dr**2,diag,-.5*np.ones(cells-1)/dr**2],[-1,0,1],format='csc'); V=.5*r*r; g=Nat*a/aho/r**2
 U=np.sqrt(np.maximum(muTF-V,0)/g); U/=np.sqrt(dr*np.dot(U,U)); mu=muTF
 for it in range(100):
  F=T@U+(V+g*U*U-mu)*U; norm=dr*np.dot(U,U)-1
  if max(np.linalg.norm(F)*np.sqrt(dr),abs(norm))<2e-11:break
  J=T+diags(V+3*g*U*U-mu)
  block=bmat([[J,csc_matrix(-U[:,None])],[csc_matrix(2*dr*U[None,:]),csc_matrix((1,1))]],format='csc')
  dx=spsolve(block,-np.r_[F,norm]); merit=np.linalg.norm(np.r_[F*np.sqrt(dr),norm]); rate=1.
  for ls in range(20):
   Ut=U+rate*dx[:-1]; mt=mu+rate*dx[-1]; ft=T@Ut+(V+g*Ut*Ut-mt)*Ut; nt=dr*np.dot(Ut,Ut)-1
   if np.linalg.norm(np.r_[ft*np.sqrt(dr),nt])<merit:break
   rate*=.5
  U,mu=Ut,mt
 F=T@U+(V+g*U*U-mu)*U; residual=np.linalg.norm(F)*np.sqrt(dr)
 assert residual<1e-8 and np.min(U)>-1e-9
 # Symplectic zero mode is removed by projection orthogonal to condensate.
 Z=null_space((U*np.sqrt(dr))[None,:]); hm=Z.T@(T.toarray()+np.diag(V+g*U*U-mu))@Z; hp=Z.T@(T.toarray()+np.diag(V+3*g*U*U-mu))@Z
 vals,W=eigh(hm); assert vals.min()>0
 S=(W*np.sqrt(vals))@W.T; Si=(W/np.sqrt(vals))@W.T
 ev,z=eigh(S@hp@S); energies=np.sqrt(ev); assert ev.min()>0
 f=Z@Si@z[:,:40]*np.sqrt(energies[:40])[None,:]
 # U_b = b^-1/2 U(r/b) in radial normalization.
 tangent=-.5*U-r*np.gradient(U,dr); tangent-=U*(dr*np.dot(U,tangent))
 al=np.sqrt(Nat*dr)*f.T@tangent
 normmass=Nat*dr*np.dot(U,r*r*U) # Mb/(hbar/omega)
 proxy=2*np.sum(al[1:]**2/energies[1:40])/normmass
 ek=Nat*dr*np.dot(U,T@U); ep=Nat*dr*np.dot(U,V*U); ei=Nat*.5*dr*np.dot(U,g*U**3)
 third=-24*ek-60*ei
 row={'cells':cells,'newton_iterations':it,'mu_over_hw':float(mu),'gp_residual_over_hw':float(residual),'normalization_error':float(dr*np.dot(U,U)-1),'lowest_gaps_over_hw':energies[:5].tolist(),'energy_third_over_hw':float(third),'virial_fraction':float((2*ek-2*ep+3*ei)/(ek+ep+ei)),'projected_overlap_sum_40_modes':float(np.dot(al,al)),'lowest_weight':float(al[0]**2/np.dot(al,al)),'formal_remainder_fraction_NOT_extra_mass':float(proxy)}
 out.append(row); print(row,flush=True)
root=Path(__file__).resolve().parents[1]; (root/'results'/'converged_gp.json').write_text(json.dumps({'N':Nat,'a_ho_um':aho*1e6,'runs':out},indent=2))
