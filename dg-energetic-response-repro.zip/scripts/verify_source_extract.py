from pathlib import Path
import json,numpy as np,openpyxl
root=Path(__file__).resolve().parents[1]
w=openpyxl.load_workbook(root/'data/Wang_Yang_2023_Source_Data.xlsx',data_only=True,read_only=True)
a=np.array(list(w['Fig3a_278e_Coulomb'].values)[1:],float)
b=np.loadtxt(root/'data/wang_yang_2023_fig3a_nu2-7_8e_coulomb.csv',delimiter=',',skiprows=1)
assert a.shape==b.shape and np.array_equal(a,b)
r={'publisher_sheet':'Fig3a_278e_Coulomb','shape':list(a.shape),'maximum_absolute_difference':float(np.max(abs(a-b)))}
(root/'results/source_comparison.json').write_text(json.dumps(r,indent=2));print(r)
