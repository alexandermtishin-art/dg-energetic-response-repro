"""Runs every reproducibility script in this directory and reports
pass/fail. Run via `python3 scripts/run_all.py` from the repo root (it
changes into its own directory first) or directly from inside scripts/.

Order matters: the numerical verification scripts run first (figures 1 and
3 pull already-computed numbers out of results/*.json rather than
duplicating them), then the three figure-generation scripts.
"""
import os
import subprocess
import sys

VERIFY_SCRIPTS = [
    "verify_response.py",
    "converged_gp.py",
    "verify_source_extract.py",
    "verify_moments.py",
    "verify_equilibrium_bridge.py",
    "verify_gravity_access.py",
    "verify_orientation_bounds.py",
    "verify_rotating_bec.py",
]

FIGURE_SCRIPTS = [
    "fig1_two_channel_diagram.py",
    "fig2_gap_graph.py",
    "fig3_response_bounds.py",
]

if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    env = dict(os.environ, OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1")
    failures = []
    for script in VERIFY_SCRIPTS + FIGURE_SCRIPTS:
        print("\n" + "#" * 70)
        print(f"# Running {script}")
        print("#" * 70)
        result = subprocess.run([sys.executable, script], env=env)
        if result.returncode != 0:
            failures.append(script)
    print("\n" + "=" * 70)
    if failures:
        print(f"FAILED: {failures}")
        sys.exit(1)
    else:
        print("All scripts ran successfully. See ../results/*.json and ../figures/*.png")
