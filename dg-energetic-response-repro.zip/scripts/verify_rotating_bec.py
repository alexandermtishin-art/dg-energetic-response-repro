from pathlib import Path
import json
import numpy as np
import sympy as s
a,c,u,t,b,z=s.symbols('a c u t b z', positive=True)
# Angular momentum conservation gives Omega(t)=Omega0/b(t)^2.
rad=-a*b+u/b**3+(a-u)/(b**3*z)
ax=-c*z+c/(b**2*z**2)
J=-s.Matrix([rad,ax]).jacobian([b,z]).subs({b:1,z:1})
assert J==s.Matrix([[4*a,a-u],[2*c,3*c]])
assert s.simplify(J.trace()-(4*a+3*c))==0
assert s.simplify(J.det()-2*c*(5*a+u))==0
T=4*(a+t)+3*(c-2*t)
P=2*(c-2*t)*(5*(a+t)+u)
jdet=s.simplify(s.Matrix([T,P]).jacobian([t,u]).det())
assert jdet==-4*(c-2*t)
# For polytropic exponent gamma, the trace depends on rotation unless gamma=1.
g=s.symbols('gamma')
radg=-a*b+u/b**3+(a-u)/(b**(2*g+1)*z**g)
axg=-c*z+c/(b**(2*g)*z**(g+1))
Jg=-s.Matrix([radg,axg]).jacobian([b,z]).subs({b:1,z:1})
assert s.simplify(Jg.trace()-(2*(1+g)*a+(2+g)*c+2*(1-g)*u))==0
rng=np.random.default_rng(20261004)
err=0; margin=1e99
for _ in range(500):
 av,cv=np.exp(rng.uniform(-2,2,2));uv=av*rng.uniform(.02,.97)
 ev=np.linalg.eigvals([[4*av,av-uv],[2*cv,3*cv]])
 assert np.all(np.isreal(ev)) and np.min(ev)>0
 err=max(err,abs(sum(ev)-(4*av+3*cv))/(4*av+3*cv))
 margin=min(margin,float(np.min(ev)))
fp,fz,fr=100.,50.,80.
a0,c0,u0=(2*np.pi*np.array([fp,fz,fr]))**2
mat=np.array([[4*a0,a0-u0],[2*c0,3*c0]])
w2=np.sort(np.linalg.eigvals(mat));fs=np.sqrt(w2)/(2*np.pi)
tide=9.81/6.371e6
change=-2*tide/(2*np.pi)**2
sigma1=abs(change)/(2*np.sqrt(sum(fs**2)))
# Analytic first derivatives avoid subtracting nearly equal terrestrial frequencies.
D=np.sqrt((4*a0-3*c0)**2+8*c0*(a0-u0))
Tp=-2.;Pp=2*(-2*(5*a0+u0)+5*c0)
derplus=(Tp*w2[1]-Pp)/D
dermin=(Pp-Tp*w2[0])/D
shifts=np.array([dermin,derplus])*tide/(4*np.pi*np.sqrt(w2))
# A tide is exactly a particular displacement of the two trap curvatures.
assert J.diff(a)-2*J.diff(c)==J.subs({a:a+t,c:c-2*t}).diff(t)
out={'model':'3D mean-field Thomas-Fermi, axisymmetric dense vortex lattice, torque-free compression; no DG interaction assumed','symbolic_scaling_matrix':str(J),'trace':'4*a+3*c','determinant':'2*c*(5*a+u)','tidal_rotation_jacobian_det':str(jdet),'polytropic_trace':str(s.simplify(Jg.trace())),'random_samples':500,'max_relative_trace_error':err,'min_positive_eigenvalue':margin,'example':{'trap_radial_Hz':fp,'trap_axial_Hz':fz,'rotation_Hz':fr,'mode_frequencies_Hz':fs.tolist(),'sum_squared_frequencies_Hz2':float(sum(fs**2)),'tide_s-2':tide,'tidal_change_sum_Hz2':change,'individual_tidal_shifts_Hz':shifts.tolist(),'equal_independent_per_mode_sigma_Hz_for_SNR1':sigma1,'equal_independent_per_mode_sigma_Hz_for_SNR5':sigma1/5},'checks':'symbolic scaling, trace, determinant, inverse-map rank, equation-of-state dependence, 500 stable matrices','scope':'No forecast of experimental attainability; no quantum-pressure, temperature, vortex-elasticity or detector corrections included.'}
root=Path(__file__).resolve().parent.parent
if (root/'results').is_dir():dst=root/'results'/'rotating_bec_checks.json'
else:dst=Path(__file__).with_name('rotating_bec_checks.json')
dst.write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
