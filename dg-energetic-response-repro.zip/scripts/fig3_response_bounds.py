"""
Figure 3 (current manuscript numbering): "Distinct uses of response bounds."

Left panel: the BEC upper-bound fraction cannot presently be assigned,
because the coupling norm, linear-coupling applicability and metric
identification remain to be established (Sec. 9). The stationary GP
calculation (converged_gp.py) supplies an energy derivative, not those
missing premises -- so the left panel is deliberately drawn as "not
assignable" rather than given a placeholder number.

Right panel: conditional two-mode Cauchy-Schwarz lower-bound ratios
(chi_F / bound, as a percentage) for the three FQH cases audited in
Sec. 10.4, using only numbers already verified elsewhere in this
reproducibility archive:
  - 100%    exactly equal gaps (saturation; the Laughlin / near-degenerate
            structural closures)
  - 104.66% engineered nu=2/9 case, r=0.05, rho=30 (verify_response.py's
            moment-excess check; matches the manuscript's "4.66%" excess)
  - 119.38% realistic nu=2/7 case, r=0.7566782, rho=2.8 (verify_source_extract.py
            + verify_response.py; matches the manuscript's "19.38%" excess)

No new numbers are introduced here: every value plotted is already computed
and verified by moment_checks.json / response_checks.json / source_comparison.json
produced by this archive's other scripts. This script only visualizes them,
matching the manuscript's Figure 3 and Table 5.
"""
import json
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams["font.family"] = "Liberation Serif"
plt.rcParams["font.size"] = 11

RESULTS = os.path.join(os.path.dirname(__file__), "..", "results")


def load_excess_percentages():
    """Pull the two conditional excess percentages directly from this
    archive's own verified results (no number is duplicated by hand):
    - realistic nu=2/7 (r=0.7566782, rho=2.8): moment_checks.json's
      second_moment_excess (run verify_moments.py first)
    - engineered nu=2/9 (r=0.05, rho=30): response_checks.json's
      spectral_moments.illustrative_005_30_excess (run verify_response.py
      first)
    Falls back to the manuscript-matching literals, clearly flagged, only
    if run_all.py has not been run yet and the results files are absent."""
    try:
        with open(os.path.join(RESULTS, "moment_checks.json")) as f:
            realistic = 100.0 * (1.0 + json.load(f)["second_moment_excess"])
    except (FileNotFoundError, KeyError):
        print("WARNING: results/moment_checks.json not found -- run "
              "verify_moments.py (or run_all.py) first. Using the "
              "manuscript-matching literal 119.38% instead.")
        realistic = 119.38
    try:
        with open(os.path.join(RESULTS, "response_checks.json")) as f:
            engineered = 100.0 * (1.0 + json.load(f)["spectral_moments"]["illustrative_005_30_excess"])
    except (FileNotFoundError, KeyError):
        print("WARNING: results/response_checks.json not found -- run "
              "verify_response.py (or run_all.py) first. Using the "
              "manuscript-matching literal 104.66% instead.")
        engineered = 104.66
    return engineered, realistic


engineered_pct, realistic_pct = load_excess_percentages()

fig, (axL, axR) = plt.subplots(1, 2, figsize=(8.6, 4.0), dpi=200,
                                gridspec_kw={"width_ratios": [1, 1.3]})

# --- Left panel: BEC, deliberately not assignable ---
axL.set_xlim(0, 1)
axL.set_ylim(0, 1)
axL.axis("off")
axL.add_patch(plt.Rectangle((0.08, 0.30), 0.84, 0.40, fill=False,
                             linestyle="--", linewidth=1.3, edgecolor="#555555"))
axL.text(0.5, 0.50, "BEC upper-bound\nfraction: not assignable",
          ha="center", va="center", fontsize=10.5, color="#333333")
axL.text(0.5, 0.14,
          "Coupling norm, linear-coupling\napplicability and metric\n"
          "identification remain to be\nestablished (Sec. 9)",
          ha="center", va="center", fontsize=8.6, style="italic", color="#555555")
axL.set_title("BEC (Sec. 9)", fontsize=11)

# --- Right panel: FQH conditional lower-bound ratios ---
labels = ["Equal gaps\n(saturation)", f"Engineered ν=2/9\nr=0.05, ρ=30",
          f"Realistic ν=2/7\nr=0.757, ρ=2.8"]
values = [100.0, engineered_pct, realistic_pct]
colors = ["#8a8a8a", "#eb6834", "#2a78d6"]

bars = axR.bar(range(3), values, color=colors, alpha=0.85, width=0.6)
axR.set_xticks(range(3))
axR.set_xticklabels(labels, fontsize=8.8)
axR.axhline(100.0, color="black", linewidth=1.0, linestyle=":")
axR.set_ylabel(r"$\chi_F$ / Cauchy–Schwarz bound (%)")
axR.set_ylim(0, 135)
for b, v in zip(bars, values):
    axR.text(b.get_x() + b.get_width() / 2, v + 2, f"{v:.2f}%",
              ha="center", fontsize=9)
axR.set_title("FQH ν=2/7, ν=2/9 (Sec. 10.4)", fontsize=11)
axR.text(1.0, -0.30,
          "Conditional two-mode ratios for the specified inputs only;\n"
          "no experimental error bar, no claim of new physics.",
          ha="center", va="top", fontsize=7.8, style="italic", color="#555555",
          transform=axR.transAxes)

fig.suptitle("Distinct uses of response bounds", fontsize=12.5, y=1.02)
plt.tight_layout()
plt.savefig("../figures/response_bounds.png", dpi=200, bbox_inches="tight")
print("Wrote ../figures/response_bounds.png")
print(f"Plotted ratios: 100.00%, {engineered_pct:.2f}%, {realistic_pct:.2f}%")
