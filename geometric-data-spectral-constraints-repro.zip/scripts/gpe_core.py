"""
Development/test version of the B1/B3 GPE+Bogoliubov core routines.
Run with reduced grid to validate correctness before producing the
full-resolution Colab notebook.
"""
import numpy as np
from scipy.linalg import eigh_tridiagonal, eig

# ---------------------------------------------------------------------
# Physical constants and 87Rb / trap parameters (matching the paper's
# own worked numbers, see dg_repro_archive/scripts/sec9_1_vard_regularization.py)
# ---------------------------------------------------------------------
hbar = 1.054571817e-34
u_mass = 1.66053906660e-27
m = 86.909180527 * u_mass
a_s = 5.8e-9
omega0 = 2 * np.pi * 100.0
n0_peak_target = 1e14 * 1e6  # m^-3
g_int = 4 * np.pi * hbar**2 * a_s / m

mu_guess = g_int * n0_peak_target
R_TF_guess = np.sqrt(2 * mu_guess / (m * omega0**2))
print("R_TF_guess (um) =", R_TF_guess * 1e6)


def build_grid(r_max, N):
    dr = r_max / N
    r = (np.arange(N) + 0.5) * dr  # cell-centered, avoids r=0 exactly
    return r, dr


def trap_potential(r):
    return 0.5 * m * omega0**2 * r**2


def laplacian_1d_matrix(N, dr):
    # returns the tridiagonal (diag, off-diag) for -d^2/dr^2.
    # Outer boundary (r=r_max): Dirichlet, U=0 just past the last point.
    # Inner boundary (r=0, first cell at r=dr/2): odd reflection U(-r)=-U(r),
    # since U(r)=r*psi(r) is an odd function of r for smooth, even psi at the origin.
    main = 2.0 / dr**2 * np.ones(N)
    main[0] = 3.0 / dr**2
    off = -1.0 / dr**2 * np.ones(N - 1)
    return main, off


def imaginary_time_ground_state(r, dr, N_target, d_tau=None, n_steps=40000, tol=1e-12, verbose=True):
    """
    Find the GPE ground state U(r) (with density n(r) = U(r)^2/(4 pi r^2))
    via normalized imaginary-time propagation, semi-implicit (Crank-Nicolson
    for the kinetic term, explicit for potential+nonlinear).
    """
    N = len(r)
    V = trap_potential(r)

    # Initial guess: Thomas-Fermi profile
    mu0 = mu_guess
    R0 = np.sqrt(2 * mu0 / (m * omega0**2))
    n_tf = np.clip((mu0 - V) / g_int, 0, None)
    U = np.sqrt(np.clip(n_tf * 4 * np.pi * r**2, 0, None))
    norm = np.trapezoid(U**2, r)
    U *= np.sqrt(N_target / norm)

    main_diag, off_diag = laplacian_1d_matrix(N, dr)
    kin_coef = hbar**2 / (2 * m)

    if d_tau is None:
        d_tau = 2e-3 / omega0  # small fraction of the trap period; CN kinetic step is
        # unconditionally stable, but the EXPLICIT nonlinear/potential half-steps are not,
        # so d_tau must be small compared to hbar/mu and hbar/(trap level spacing).

    # Crank-Nicolson matrices for the kinetic part: (I + i dt/2 H_kin/hbar) ... but this is
    # imaginary time so just use implicit Euler for kinetic (stable, simple) + explicit
    # potential/nonlinear each half-step (standard split-step).
    A_main = 1.0 + 0.5 * d_tau * kin_coef * main_diag / hbar
    A_off = 0.5 * d_tau * kin_coef * off_diag / hbar

    mu_track = mu0
    for step in range(n_steps):
        n_r = U**2 / (4 * np.pi * r**2)
        Veff = V + g_int * n_r
        # explicit half-step: potential + nonlinear
        U_half = U * np.exp(-0.5 * d_tau * Veff / hbar)
        # implicit half-step: kinetic (Crank-Nicolson style via tridiagonal solve)
        # RHS = (I - 0.5 dtau kin_coef/hbar * Lap) U_half
        rhs = (1.0 - 0.5 * d_tau * kin_coef * main_diag / hbar) * U_half
        rhs[:-1] += -0.5 * d_tau * kin_coef * off_diag / hbar * U_half[1:]
        rhs[1:] += -0.5 * d_tau * kin_coef * off_diag / hbar * U_half[:-1]
        U_new = solve_tridiag(A_main, A_off, rhs)
        # explicit half-step again
        n_r_new = U_new**2 / (4 * np.pi * r**2)
        Veff_new = V + g_int * n_r_new
        U_new = U_new * np.exp(-0.5 * d_tau * Veff_new / hbar)

        norm = np.trapezoid(U_new**2, r)
        U_new *= np.sqrt(N_target / norm)

        diff = np.max(np.abs(U_new - U)) / (np.max(np.abs(U)) + 1e-300)
        U = U_new
        if diff < tol and step > 50:
            if verbose:
                print(f"converged at step {step}, diff={diff:.3e}")
            break
    else:
        if verbose:
            print(f"did not fully converge, final diff={diff:.3e}")

    # chemical potential via energy functional derivative (Pitaevskii formula):
    # mu = (1/N) * integral [ hbar^2/2m (dU/dr)^2/... ] -- simpler: use the
    # standard mu = E_kin + E_pot + 2*E_int (per particle) relation isn't needed;
    # instead extract mu from the stationary GPE residual directly.
    mu = compute_mu(U, r, dr, V)
    return U, mu


def solve_tridiag(main, off, rhs):
    N = len(main)
    # Thomas algorithm
    cp = np.zeros(N - 1)
    dp = np.zeros(N)
    cp[0] = off[0] / main[0]
    dp[0] = rhs[0] / main[0]
    for i in range(1, N - 1):
        m_ = main[i] - off[i - 1] * cp[i - 1]
        cp[i] = off[i] / m_
        dp[i] = (rhs[i] - off[i - 1] * dp[i - 1]) / m_
    m_ = main[N - 1] - off[N - 2] * cp[N - 2]
    dp[N - 1] = (rhs[N - 1] - off[N - 2] * dp[N - 2]) / m_
    x = np.zeros(N)
    x[-1] = dp[-1]
    for i in range(N - 2, -1, -1):
        x[i] = dp[i] - cp[i] * x[i + 1]
    return x


def apply_H_GP(U, r, dr, V):
    """Apply -hbar^2/2m d^2U/dr^2 + V U + g n(r) U, Dirichlet BC."""
    N = len(U)
    lap = np.zeros(N)
    lap[1:-1] = (U[2:] - 2 * U[1:-1] + U[:-2]) / dr**2
    lap[0] = (U[1] - 3 * U[0]) / dr**2  # odd reflection U(-r)=-U(r) about r=0 (u=r*psi is odd)
    lap[-1] = (0.0 - 2 * U[-1] + U[-2]) / dr**2
    n_r = U**2 / (4 * np.pi * r**2)
    return -hbar**2 / (2 * m) * lap + V * U + g_int * n_r * U


def compute_mu(U, r, dr, V):
    HU = apply_H_GP(U, r, dr, V)
    num = np.trapezoid(U * HU, r)
    den = np.trapezoid(U * U, r)
    return num / den


if __name__ == "__main__":
    Natoms = (8 * np.pi / 15) * n0_peak_target * R_TF_guess**3
    print("Natoms =", Natoms)
    Ngrid = 400
    r_max = 3.2 * R_TF_guess
    r, dr = build_grid(r_max, Ngrid)
    U, mu = imaginary_time_ground_state(r, dr, N_target=Natoms, n_steps=6000, verbose=True)
    print("mu/hbar/omega0 =", mu / (hbar * omega0), " (paper: 8.47)")
    n_r = U**2 / (4 * np.pi * r**2)
    print("peak density (m^-3) =", n_r.max(), " target =", n0_peak_target)
    R_TF_num = np.sqrt(2 * mu / (m * omega0**2))
    print("R_TF from mu (um) =", R_TF_num * 1e6, " (paper: 4.436)")
