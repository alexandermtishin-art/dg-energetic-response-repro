import numpy as np
from scipy.linalg import eig
from gpe_core import (hbar, m, g_int, omega0, n0_peak_target, R_TF_guess,
                       build_grid, trap_potential, imaginary_time_ground_state,
                       laplacian_1d_matrix)


def build_L_matrix(U, r, dr, V, mu):
    N = len(U)
    n_r = U**2 / (4 * np.pi * r**2)
    main, off = laplacian_1d_matrix(N, dr)
    kin_coef = hbar**2 / (2 * m)
    L_main = kin_coef * main + V + 2 * g_int * n_r - mu
    L_off = kin_coef * off
    return L_main, L_off, n_r


def dense_from_tridiag(main, off):
    N = len(main)
    A = np.diag(main) + np.diag(off, 1) + np.diag(off, -1)
    return A


def bdg_spectrum(U, r, dr, V, mu, n_modes_report=40):
    N = len(U)
    L_main, L_off, n_r = build_L_matrix(U, r, dr, V, mu)
    L = dense_from_tridiag(L_main, L_off)
    M = np.diag(g_int * n_r)

    BdG = np.zeros((2 * N, 2 * N))
    BdG[:N, :N] = L
    BdG[:N, N:] = -M
    BdG[N:, :N] = M
    BdG[N:, N:] = -L

    evals, evecs = eig(BdG)
    evals = evals.real  # should be real for a stable condensate (imaginary parts ~ numerical noise)
    # physical modes: Delta_n > 0 (positive norm branch)
    order = np.argsort(evals)
    evals_sorted = evals[order]
    evecs_sorted = evecs[:, order]

    # keep positive-energy modes above a small cutoff (exclude ~0 Goldstone mode and negative branch)
    cutoff = 1e-6 * hbar * omega0
    pos_mask = evals_sorted > cutoff
    evals_pos = evals_sorted[pos_mask]
    evecs_pos = evecs_sorted[:, pos_mask]

    K = min(n_modes_report, len(evals_pos))
    Delta = evals_pos[:K]
    modes = []
    for k in range(K):
        vec = evecs_pos[:, k]
        u_n = vec[:N]
        v_n = vec[N:]
        # normalize: integral (|u|^2 - |v|^2) dr = 1  (standard BdG normalization)
        normfac = np.trapezoid(u_n**2 - v_n**2, r)
        if normfac <= 0:
            # skip pathological modes (shouldn't normally happen for the lowest physical branch)
            continue
        u_n = u_n / np.sqrt(normfac)
        v_n = v_n / np.sqrt(normfac)
        modes.append((Delta[k], u_n, v_n))
    return modes, n_r


if __name__ == "__main__":
    Natoms = (8 * np.pi / 15) * n0_peak_target * R_TF_guess**3
    Ngrid = 500
    r_max = 3.2 * R_TF_guess
    r, dr = build_grid(r_max, Ngrid)
    V = trap_potential(r)
    U, mu = imaginary_time_ground_state(r, dr, N_target=Natoms, n_steps=6000, verbose=False)
    print("mu/hbar/omega0 =", mu / (hbar * omega0))

    modes, n_r = bdg_spectrum(U, r, dr, V, mu, n_modes_report=15)
    print("Lowest l=0 BdG excitation energies (units of hbar*omega0):")
    for Delta, u_n, v_n in modes:
        print(f"  {Delta/(hbar*omega0):.6f}")
    print("Castin-Dum/Stringari TF prediction for the lowest monopole (breathing) mode: sqrt(5) =", np.sqrt(5))
