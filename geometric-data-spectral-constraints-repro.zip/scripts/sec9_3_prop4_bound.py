"""
Reproduces the numerical claims of Sec. 9.3 ("B3 -- Anharmonicity /
self-limitation") and the exact classical reference value it is compared
against.

Two independent pieces:

(A) EXACT, model-independent piece: the classical Thomas-Fermi
    scale-parameter equation
        b'' + omega0^2 * b = omega0^2 / b^4
    equivalent to motion in the potential
        U(b) = (omega0^2/2) b^2 + (omega0^2/3) b^-3.
    This script symbolically/analytically expands U(b) about b=1 and
    evaluates U''(1) and U'''(1) exactly (no fitting, no free parameters).
    It also evaluates the physical, macroscopic |E'''(b*)| directly from
    the full Gross-Pitaevskii energy functional (A/b^2 + B*b^2 + C/b^3),
    at the family's own equilibrium b*, as a cross-check on the Mb-scaled
    auxiliary-equation estimate.

(B) Proposition 4's conditional bound 6*W*g. g = sum_n alpha_n^2, where
    alpha_n = <n|(u_n+v_n)|delta_psi> is the same Bogoliubov-de Gennes
    overlap coefficient already used in sec9_1 for the adiabatic mass
    correction (delta_M = 2 hbar^2 sum_n alpha_n^2/Delta_n). Standard
    first-order perturbation theory identifies alpha_n with the component
    <n|v> of Prop.4's |v> = R^ A|0>, so no further division by Delta_n is
    needed (this supersedes an earlier version of this script, and of the
    manuscript text, that used g ~= Var(D)/5 -- a single-particle dilation-
    generator proxy not established at the condensate's own macroscopic
    normalization). W ~= mu, the natural interaction-energy bound on the
    coupling operator's spectral width (unchanged from the earlier
    version): both g and W are now evaluated from the same exact,
    N-particle Gross-Pitaevskii/Bogoliubov-de Gennes state as |E'''(b*)|,
    so the comparison 6Wg vs |E'''(b*)| is made at one consistent,
    macroscopic normalization throughout, with no separate unit-mass
    convention involved.
"""
import numpy as np
from scipy.optimize import brentq
from gpe_core import (hbar, m, g_int, omega0, n0_peak_target, R_TF_guess,
                       build_grid, trap_potential, imaginary_time_ground_state)
from bdg import bdg_spectrum

print("=" * 70)
print("Part A: exact classical reference term from U(b)")
print("=" * 70)
# U(b) = (w0^2/2) b^2 + (w0^2/3) b^-3   (set omega0 = 1; result scales as omega0^2)
# U'(b)  =  w0^2 b - w0^2 b^-4
# U''(b) =  w0^2 + 4 w0^2 b^-5
# U'''(b) = -20 w0^2 b^-6
# At b = 1:
Upp_1 = 1.0 + 4.0     # in units of omega0^2
Uppp_1 = -20.0        # in units of omega0^2

print("U(b)  = (w0^2/2) b^2 + (w0^2/3) b^-3")
print("U'(b) =  w0^2 (b - b^-4)          -> U'(1) = 0  (equilibrium, as required)")
print("U''(b) = w0^2 (1 + 4 b^-5)        -> U''(1)  =", Upp_1, " * omega0^2  (paper: 5)")
print("U'''(b) = -20 w0^2 b^-6           -> U'''(1) =", Uppp_1, "* omega0^2  (paper: -20)")

print()
print("=" * 70)
print("Part B: exact Gross-Pitaevskii ground state, BdG spectrum, and g")
print("=" * 70)

Natoms = (8 * np.pi / 15) * n0_peak_target * R_TF_guess ** 3
Ngrid = 500
r_max = 3.2 * R_TF_guess
r, dr = build_grid(r_max, Ngrid)
V = trap_potential(r)
U0, mu = imaginary_time_ground_state(r, dr, N_target=Natoms, n_steps=6000, verbose=False)
psi0 = U0 / (np.sqrt(4 * np.pi) * r)
n0r = U0 ** 2 / (4 * np.pi * r ** 2)
hw0 = hbar * omega0

# Exact E(b) = A/b^2 + B b^2 + C/b^3 for the scaling ansatz psi_b(r) = b^-3/2 psi0(r/b)
dUdr = np.gradient(U0, r)
A = hbar ** 2 / (2 * m) * np.trapezoid(dUdr ** 2, r)
B = np.trapezoid(V * n0r * 4 * np.pi * r ** 2, r)
C = 0.5 * g_int * np.trapezoid(n0r ** 2 * 4 * np.pi * r ** 2, r)

def Ep(b):
    return -2 * A / b ** 3 + 2 * B * b - 3 * C / b ** 4

def Eppp(b):
    return -24 * A / b ** 5 - 60 * C / b ** 6

bstar = brentq(Ep, 0.9, 1.1, xtol=1e-14)
Eppp_star = Eppp(bstar)
classical = abs(Eppp_star / hw0)
print(f"b* = {bstar:.6f}  (paper: ~1.0017)")
print(f"|E'''(b*)|/hbar*omega0 = {classical:.6e}  (paper: 2.13e6)")

# g = sum_n alpha_n^2, alpha_n = <(u_n+v_n)|delta_psi>, delta_psi = d(psi_b)/db at b=1
dpsi0_dr = np.gradient(psi0, r)
delta_psi = -1.5 * psi0 - r * dpsi0_dr
delta_U = np.sqrt(4 * np.pi) * r * delta_psi

modes, _ = bdg_spectrum(U0, r, dr, V, mu, n_modes_report=40)
alphas = [(Delta, np.trapezoid((u_n + v_n) * delta_U, r).real) for Delta, u_n, v_n in modes]
g = sum(a ** 2 for _, a in alphas)
Delta0, alpha0 = alphas[0]
purity = alpha0 ** 2 / g
print(f"Delta0/hbar*omega0 = {Delta0 / hw0:.5f}  (paper: ~2.245, i.e. sqrt(5))")
print(f"g = sum_n alpha_n^2 = {g:.6e}  (paper: 1.20e5; converged already by 5 modes)")
print(f"breathing-mode purity (alpha0^2/g) = {purity:.4%}  (paper: 99.8%)")

mu_hw0 = mu / hw0
bound_6Wg = 6 * mu_hw0 * g
eta = classical / bound_6Wg * 100
headroom = bound_6Wg / classical

print()
print(f"W = mu/hbar*omega0 = {mu_hw0:.4f}  (paper: 8.65)")
print(f"6Wg = {bound_6Wg:.4e} hbar*omega0  (paper: 6.23e6)")
print(f"eta = |E'''(b*)| / 6Wg = {eta:.2f}%  (paper: 34.2%)")
print(f"headroom factor 6Wg/|E'''(b*)| = {headroom:.3f}  (paper: 2.9)")

# Self-consistency cross-check: the same alpha_n reproduce Mb via the
# independently-trusted D'Alessio-Polkovnikov mass formula (sec9_1).
Mb = m * np.trapezoid(r ** 2 * U0 ** 2, r)
Mb_check = 2 * hbar ** 2 * alpha0 ** 2 / Delta0
print()
print(f"Cross-check: single-mode-implied Mb = {Mb_check:.4e} kg m^2 "
      f"vs. true Mb = {Mb:.4e} kg m^2 (ratio {Mb_check / Mb:.4f}, paper: within 2.3%)")
