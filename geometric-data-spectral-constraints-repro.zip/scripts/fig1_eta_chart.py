import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

plt.rcParams["font.family"] = "Liberation Serif"
plt.rcParams["font.size"] = 11

# Editorial remark #4 (review.md): the Proposition-4 upper-bound channel
# (BEC anharmonicity) and the Cauchy-Schwarz lower-bound channels (FQH)
# are two structurally different kinds of quantity -- "distance below
# 100%" means unused capacity for one and redundancy for the other --
# and must not be drawn as one shared ranking on one axis, even with a
# caveat in the caption. This version draws them as two separate panels
# with independent x-axes, so the two kinds of number cannot be read
# off a single shared scale.
#
# Left panel: the one upper-bound-type channel (Prop. 4).
# Right panel: the four lower-bound-type (Cauchy-Schwarz) channels.
#
# Data provenance (unchanged from the single-panel version):
# - BEC anharmonicity: exact numerical Gross-Pitaevskii ground state +
#   Bogoliubov-de Gennes spectrum (no edge-regularization kernel) gives
#   g = sum_n alpha_n^2 = 1.20e5, from the same alpha_n overlap
#   coefficients already used for the Sec. 9.1 mass-correction check,
#   hence eta~=34.2% (6Wg~=6.23e6 hbar*omega0 vs the exact classical
#   term |E'''(b*)|/hbar*omega0~=2.13e6, both at the condensate's own
#   macroscopic normalization). See Sec. 9.1, 9.3 and the accompanying
#   GPE+BdG notebook.
# - Engineered nu=2/9: exact two-mode Cauchy-Schwarz excess formula
#   derived in Sec. 10.3 (~4.7%, see sec10_4_exact_cauchy_schwarz.py).
#   This is a two-mode approximation; the system's reported third mode
#   is not included (Sec. 10.4).
# - Realistic nu=2/7 (lowest LL, ordinary Coulomb interaction, NOT
#   engineered): combines the exact spectral-weight ratio w2/w1=0.757
#   computed from Wang & Yang (Nat. Commun. 14, 2317, 2023) Source Data
#   with the gap ratio Delta2/Delta1~=2.8 measured directly by Yang et
#   al. (Nature Physics 22, 1230, 2026) -- a conditional combination of
#   two independent sources (Sec. 10.4). The one channel in this paper
#   not closed by any argument used elsewhere.
# - TBG geometric-weight channel: not included here (Sec. 13's
#   qualification): that number is a direct band-geometry identity, not
#   a Cauchy-Schwarz-type saturation, and is not commensurable with
#   either panel's axis.
# - SLL near-degenerate Jain nu=2/7: kept at the theoretical 100%
#   (exact-degeneracy) idealization, labeled "~100%*" since near-
#   degenerate gaps are not exactly degenerate and exact saturation is
#   not independently verified for this case (Sec. 10.4).

upper_data = [
    ("BEC anharmonicity\n(Prop. 4, §9.3)", 34.2),
]

lower_data = [
    ("FQH, Laughlin states\n(§10.4)", 100.0, "lower"),
    ("FQH, SLL near-degenerate\nJain ν=2/7 (§10.4)", 100.0, "lower"),
    ("FQH, engineered ν=2/9\n3-body (§10.4)", 104.7, "lower"),
    ("FQH, realistic LLL ν=2/7\n— OPEN (§10.4–10.5)", 119.4, "open"),
]

color_upper = "#2a78d6"  # blue — categorical slot 1 (validated, dataviz skill)
color_lower = "#eb6834"  # orange — categorical slot 2
color_open = "#c62828"   # red — the one open channel

fig, (ax1, ax2) = plt.subplots(
    1, 2, figsize=(11.2, 4.3), dpi=200,
    gridspec_kw={"width_ratios": [1, 2.3], "wspace": 0.55},
)

# --- Left panel: upper-bound type (Proposition 4) ----------------------
labels1 = [d[0] for d in upper_data]
for i, (label, val) in enumerate(upper_data):
    ax1.barh(i, val, color=color_upper, edgecolor="black", linewidth=0.8, height=0.5)
    ax1.text(val - 3, i, f"{val:.1f}%", va="center", ha="right", fontsize=10, color="white")

ax1.axvline(100, color="black", linewidth=1.0, linestyle="--")
ax1.text(100, 0.62, "Prop. 4 ceiling = 100%\n(distance below = unused\nresponse capacity)",
          ha="center", va="bottom", fontsize=8.3)
ax1.set_yticks(range(len(labels1)))
ax1.set_yticklabels(labels1, fontsize=10)
ax1.invert_yaxis()
ax1.set_ylim(len(labels1) - 0.3, -1.4)
ax1.set_xlim(0, 118)
ax1.set_xlabel(r"$\eta_{\mathrm{upper}}$ — fraction of the Prop. 4 bound reached (%)", fontsize=9.5)
ax1.set_title("Upper-bound type\n(Proposition 4)", fontsize=11, pad=10)
ax1.spines["top"].set_visible(False)
ax1.spines["right"].set_visible(False)

legend1 = [plt.Rectangle((0, 0), 1, 1, facecolor=color_upper, edgecolor="black", linewidth=0.8)]
ax1.legend(legend1,
           ["Exact GPE+BdG calculation,\nno edge-regularization\nkernel (§9.1/§9.3)"],
           loc="upper center", bbox_to_anchor=(0.5, -0.30), fontsize=8, frameon=False)

# --- Right panel: lower-bound type (Cauchy-Schwarz, Proposition 3) -----
labels2 = [d[0] for d in lower_data]
kinds2 = [d[2] for d in lower_data]
color_map = {"lower": color_lower, "open": color_open}
colors2 = [color_map[k] for k in kinds2]

for i, (label, val, kind) in enumerate(lower_data):
    ax2.barh(i, val, color=colors2[i], edgecolor="black", linewidth=0.8, height=0.55)
    if val != 100.0:
        txt = f"{val:.1f}%"
    elif i == 1:
        txt = "~100%*"
    else:
        txt = "100%"
    ax2.text(val - 3, i, txt, va="center", ha="right", fontsize=10, color="white")

ax2.axvline(100, color="black", linewidth=1.0, linestyle="--")
ax2.text(100, -0.85, "Cauchy–Schwarz floor = 100%  (saturation signals redundancy; exceeding it signals possible independent content)",
          ha="center", va="bottom", fontsize=8.3)
ax2.set_yticks(range(len(labels2)))
ax2.set_yticklabels(labels2, fontsize=10)
ax2.invert_yaxis()
ax2.set_ylim(len(labels2) - 0.4, -1.3)
ax2.set_xlim(0, 132)
ax2.set_xlabel(r"$\eta_{\mathrm{lower}}$ — ratio of $\chi_F$ to the Cauchy–Schwarz bound (%)", fontsize=9.5)
ax2.set_title("Lower-bound type\n(Cauchy–Schwarz, Proposition 3)", fontsize=11, pad=10)
ax2.spines["top"].set_visible(False)
ax2.spines["right"].set_visible(False)

legend2 = [
    plt.Rectangle((0, 0), 1, 1, facecolor=color_lower, edgecolor="black", linewidth=0.8),
    plt.Rectangle((0, 0), 1, 1, facecolor=color_open, edgecolor="black", linewidth=0.8),
]
ax2.legend(
    legend2,
    ["Closed: saturation (*SLL near-degenerate ν=2/7 is a theoretical\nidealization, exact degeneracy not independently verified)",
     "OPEN: exceeds the bound by more than any degeneracy/engineering\nargument in this paper closes — not yet measured directly"],
    loc="upper center", bbox_to_anchor=(0.5, -0.30), fontsize=8, frameon=False,
)

fig.suptitle(
    "Two structurally different diagnostics, not one shared ranking (§E.8)",
    fontsize=11, y=1.03,
)

plt.savefig("../figures/eta_chart.png", dpi=200, bbox_inches="tight")
print("Wrote ../figures/eta_chart.png")
