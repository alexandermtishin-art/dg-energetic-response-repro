"""
Sec. 12.1 Channel-2 protocol (picosecond strain pulse): does a self-consistent
pulse duration tau exist for the stated formula Pexc(tau) ~= chi_F*(d_eps/tau)^2
to hold?

That closed-form asymptotic scaling is the LARGE-tau limit of the exact
first-order time-dependent-perturbation-theory result for a linear strain
ramp of rate v = d_eps/tau applied over duration tau:

    P_n(tau) = 4 v^2 |M_n|^2 sin^2(Delta_n*tau/2) / Delta_n^2

which reduces to P_n ~= 2 v^2 |M_n|^2 / Delta_n^2 (i.e. sums to
Pexc ~= chi_F * v^2 with chi_F = 2*sum_n w_n/Delta_n^2, matching Sec.10.3's
definition) only once Delta_n*tau >> 1 for every mode -- i.e. the ramp must
be LONG compared to 1/Delta_n, not short, for the stated formula to be the
correct leading approximation. This script checks, using the real measured
numbers of ref. [32] (Du et al., Nature Physics 22, 1230 (2026)) for the
realistic nu=2/7 platform Sec. 12 proposes to use, whether an experimentally
sensible window of tau exists: long enough compared to 1/Delta_n for the
asymptotic formula to apply, but short enough compared to the mode's own
coherence time (set by its measured linewidth) that the excitation process
being modelled is still the coherent process the formula assumes, not one
already washed out by the intrinsic decay/dephasing the same reference
reports.

This is not a "self-limitation" (Kerr/Duffing) nonlinearity check in the
AMT-program sense -- it does not require or invoke that separate apparatus.
It is a first-principles consistency check internal to the same
Kato/adiabatic-perturbation-theory formalism already used throughout this
paper, using only inputs (Delta_0L, Delta_0H, and their linewidths) already
published in the same source the protocol itself relies on.
"""
import math

# --- physical constants ---
e = 1.602176634e-19       # C
eps0 = 8.8541878128e-12   # F/m
hbar = 1.054571817e-34    # J s
h = 6.62607015e-34        # J s
meV = 1.602176634e-22     # J per meV

# --- GaAs / sample parameters, Du et al. Nature Physics 22, 1230 (2026) ---
eps_r = 12.4              # GaAs relative permittivity
BT = 11.35                # T, total field at theta=15 deg (sample A, main nu=2/7 data)
theta_deg = 15.0
Bperp = BT * math.cos(math.radians(theta_deg))

lB = math.sqrt(hbar / (e * Bperp))
EC_J = e**2 / (4*math.pi*eps0*eps_r*lB)
EC_meV = EC_J / meV

# ref. [32], main text: "The theta=15 deg data (Fig. 3d) give
# Delta_0L ~= 0.015 E_C and Delta_0H ~= 0.042 E_C"
D0L_over_EC = 0.015
D0H_over_EC = 0.042
D0L_meV = D0L_over_EC * EC_meV
D0H_meV = D0H_over_EC * EC_meV

# ref. [32], main text: "The gravitons exhibit sharp peaks with full-width
# at half-maximum (FWHM) around 30 micro-eV (Extended Data Figs. 4-6)" --
# explicitly stated to cover both Delta_0L and Delta_0H (and Delta_0S).
FWHM_meV = 0.030

def meV_to_J(x):
    return x * meV

def tau_from_energy_ps(x_meV):
    """hbar/Delta in picoseconds -- the natural oscillation timescale
    1/Delta_n entering the adiabatic-perturbation-theory sin^2 formula."""
    return (hbar / meV_to_J(x_meV)) * 1e12

def freq_GHz(x_meV):
    return (meV_to_J(x_meV) / h) / 1e9

tau_L_ps = tau_from_energy_ps(D0L_meV)   # sets the BINDING (larger) 1/Delta_n
tau_H_ps = tau_from_energy_ps(D0H_meV)
tau_coh_ps = tau_from_energy_ps(FWHM_meV)   # hbar/Gamma, coherence-time proxy

print("=== Sec. 12.1 Channel-2 ramp-duration self-consistency check ===")
print(f"B_perp = {Bperp:.3f} T  (BT={BT} T at theta={theta_deg} deg)")
print(f"l_B = {lB*1e9:.3f} nm")
print(f"E_C = e^2/(eps_r*l_B) = {EC_meV:.3f} meV")
print()
print(f"Delta_0L = {D0L_over_EC}*E_C = {D0L_meV:.4f} meV = {freq_GHz(D0L_meV):.2f} GHz "
      f"-> hbar/Delta_0L = {tau_L_ps:.3f} ps")
print(f"Delta_0H = {D0H_over_EC}*E_C = {D0H_meV:.4f} meV = {freq_GHz(D0H_meV):.2f} GHz "
      f"-> hbar/Delta_0H = {tau_H_ps:.3f} ps")
print(f"Measured linewidth FWHM = {FWHM_meV*1000:.0f} ueV = {freq_GHz(FWHM_meV):.3f} GHz "
      f"-> hbar/FWHM (coherence-time proxy) = {tau_coh_ps:.3f} ps")
print()

margin_needed = 5.0   # require tau >= margin_needed / Delta_n for the sin^2
                      # average to be within ~few % of its asymptotic 1/2
tau_min_ps = margin_needed * tau_L_ps   # binding constraint: the SMALLER gap
                                        # (Delta_0L) needs the LONGER tau
tau_max_ps = tau_coh_ps

print(f"Adiabatic-perturbation-theory validity requires tau >> hbar/Delta_0L "
      f"(the binding, smaller gap).")
print(f"Taking 'ratio >= {margin_needed:.0f}' as a first working threshold: "
      f"tau_min ~= {tau_min_ps:.2f} ps")
print(f"Coherence-time upper bound (must stay well inside the measured "
      f"linewidth's dephasing time): tau_max ~= {tau_max_ps:.2f} ps")
print()

window_ratio = tau_max_ps / tau_min_ps
if tau_max_ps > tau_min_ps:
    print(f"NARROW SELF-CONSISTENT WINDOW EXISTS: {tau_min_ps:.1f} ps <~ tau <~ "
          f"{tau_max_ps:.1f} ps (ratio {window_ratio:.2f}x)")
else:
    print(f"NO SELF-CONSISTENT WINDOW at this margin: tau_min ({tau_min_ps:.1f} ps) "
          f"exceeds tau_max ({tau_max_ps:.1f} ps).")
print("Either way, the required tau is in the few-to-tens-of-picosecond range: "
      "an ultrafast (THz-regime) picosecond strain pulse (e.g. picosecond "
      "acoustics or a high-harmonic SAW), not a routine slow DC sweep. The "
      "gate-controlled displacement field itself remains a separate, slow DC "
      "handle used only to set the operating point kappa (Sec. 12.1).")
print()

# What happens at the margin=1 (bare minimum, no safety factor) boundary
tau_min_bare_ps = 1.0 * tau_L_ps
print(f"Bare minimum (no safety margin, Delta_0L*tau=1): tau_min_bare "
      f"~= {tau_min_bare_ps:.2f} ps, vs tau_max ~= {tau_max_ps:.2f} ps "
      f"-> ratio {tau_max_ps/tau_min_bare_ps:.2f}x")

if __name__ == "__main__":
    import json
    results = {
        "Bperp_T": Bperp,
        "lB_nm": lB*1e9,
        "EC_meV": EC_meV,
        "Delta_0L_meV": D0L_meV,
        "Delta_0H_meV": D0H_meV,
        "Delta_0L_GHz": freq_GHz(D0L_meV),
        "Delta_0H_GHz": freq_GHz(D0H_meV),
        "FWHM_meV": FWHM_meV,
        "tau_from_Delta_0L_ps": tau_L_ps,
        "tau_from_Delta_0H_ps": tau_H_ps,
        "tau_coherence_ps": tau_coh_ps,
        "tau_min_ps_margin5": tau_min_ps,
        "tau_min_ps_bare": tau_min_bare_ps,
        "tau_max_ps": tau_max_ps,
        "window_ratio_margin5": window_ratio,
        "window_ratio_bare": tau_max_ps/tau_min_bare_ps,
        "conclusion": "narrow but present window, roughly 3-22 ps bare, "
                      "~15-22 ps at a x5 safety margin on the slower mode; "
                      "requires ultrafast (picosecond-to-few-tens-of-ps) "
                      "strain-pulse control (picosecond acoustics / "
                      "high-harmonic SAW), not a routine slow gate sweep",
    }
    with open("../results/results_sec12_ramp_window.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nWrote results_sec12_ramp_window.json")
