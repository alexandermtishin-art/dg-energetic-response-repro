"""Runs every reproducibility script in this directory, in the order the
corresponding claims appear in the paper, and reports pass/fail. Run this
from inside the scripts/ directory (or via `python3 scripts/run_all.py`
from the repo root -- it changes into its own directory first)."""
import subprocess
import sys
import os

SCRIPTS = [
    "sec9_1_vard_regularization.py",
    "sec9_3_prop4_bound.py",
    "sec10_4_fqh_estimate.py",
    "sec10_4_exact_cauchy_schwarz.py",
    "sec12_ramp_window_check.py",
    "sec12_5_pulse_shape_robustness.py",
    "appendixB_fisher_information.py",
    "appendixC_parametric_pumping.py",
    "appendixD_third_order_response.py",
    "fig1_eta_chart.py",
    "fig2_gap_graph.py",
    "fig3_two_channel_diagram.py",
]

if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    failures = []
    for script in SCRIPTS:
        print("\n" + "#" * 70)
        print(f"# Running {script}")
        print("#" * 70)
        result = subprocess.run([sys.executable, script])
        if result.returncode != 0:
            failures.append(script)
    print("\n" + "=" * 70)
    if failures:
        print(f"FAILED: {failures}")
        sys.exit(1)
    else:
        print("All scripts ran successfully. See ../results/*.json and ../figures/*.png")
