"""
Figure 2: the spectral gap graph of Proposition 2 (Sec. 3.1), drawn for the
exact worked example already stated in Appendix A: five levels, edges
{1-2, 2-3, 4-5}. This graph has two connected components ({1,2,3} and
{4,5}), incidence-matrix rank 3 and nullity 2 -- matching the two connected
components exactly, as Appendix A states. Proposition 2 then says every
deformation preserving the specified projectors and gaps has the form
delta_H(q) = f_1(q) P_1(q) + f_2(q) P_2(q): one free scalar function per
connected component, and no freedom at all for the relative energies within
a component (their gaps are fixed by construction).

Purely illustrative -- no new claim, only a picture of a result already in
the text (Sec. 3.1, Prop. 2; Appendix A worked example).
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Ellipse

plt.rcParams["font.family"] = "Liberation Serif"
plt.rcParams["font.size"] = 11

color_comp1 = "#2a78d6"  # blue -- component alpha=1, matches fig1's categorical slot 1
color_comp2 = "#eb6834"  # orange -- component alpha=2, matches fig1's categorical slot 2

# Node positions: component 1 = levels 1,2,3 in a row; component 2 = levels 4,5 in a row, offset
pos = {
    1: (0.0, 0.6),
    2: (1.0, 0.6),
    3: (2.0, 0.6),
    4: (3.4, -0.3),
    5: (4.4, -0.3),
}
edges = [(1, 2), (2, 3), (4, 5)]
component_of = {1: 1, 2: 1, 3: 1, 4: 2, 5: 2}
comp_color = {1: color_comp1, 2: color_comp2}

fig, ax = plt.subplots(figsize=(7.0, 3.6), dpi=200)

# Shaded ellipse behind each connected component
ax.add_patch(Ellipse((1.0, 0.6), width=3.0, height=1.35, facecolor=color_comp1, alpha=0.12,
                      edgecolor=color_comp1, linewidth=1.2, linestyle="--", zorder=0))
ax.add_patch(Ellipse((3.9, -0.3), width=1.9, height=1.25, facecolor=color_comp2, alpha=0.12,
                      edgecolor=color_comp2, linewidth=1.2, linestyle="--", zorder=0))

# Edges (fixed, prescribed gaps)
for a, b in edges:
    xa, ya = pos[a]
    xb, yb = pos[b]
    ax.plot([xa, xb], [ya, yb], color="black", linewidth=1.6, zorder=1)
    xm, ym = (xa + xb) / 2, (ya + yb) / 2
    ax.text(xm, ym + 0.16, "fixed gap", fontsize=8, ha="center", color="black")

# Nodes
for n, (x, y) in pos.items():
    ax.add_patch(plt.Circle((x, y), 0.22, facecolor="white", edgecolor=comp_color[component_of[n]],
                             linewidth=2.2, zorder=2))
    ax.text(x, y, f"{n}", ha="center", va="center", fontsize=12, zorder=3)

ax.text(1.0, 1.55, r"component $\alpha=1$:  $\delta H \supset f_1(q)\,P_1(q)$",
        ha="center", fontsize=10.5, color=color_comp1)
ax.text(3.9, -1.15, r"component $\alpha=2$:  $\delta H \supset f_2(q)\,P_2(q)$",
        ha="center", fontsize=10.5, color=color_comp2)

ax.text(2.2, 1.95,
        r"$c=2$ connected components $\Rightarrow \delta H(q) = f_1(q)P_1(q) + f_2(q)P_2(q)$"
        "\n(incidence-matrix rank 3, nullity 2 -- Appendix A)",
        ha="center", fontsize=10, style="italic")

ax.set_xlim(-0.8, 5.4)
ax.set_ylim(-1.6, 2.3)
ax.axis("off")
ax.set_title("The gap graph of Proposition 2: five levels, edges {1–2, 2–3, 4–5}", fontsize=11, pad=10)

plt.tight_layout()
plt.savefig("../figures/gap_graph.png", dpi=200, bbox_inches="tight")
print("Wrote ../figures/gap_graph.png")
