"""
Reproduces the numerical claims of Sec. 9.1 ("B1 -- Effective mass via
adiabatic elimination") of

  A. M. Tishin, "Geometric Data, Spectral Constraints, and the Energetic
  Response of Different Physical Systems."

Two independent things are checked here:

(A) The STANDARD, textbook Gross-Pitaevskii/Thomas-Fermi parameter chain for
    a harmonically trapped 87Rb condensate: healing length xi0, Thomas-Fermi
    radius R_TF, and the resulting ln(R/xi). This chain uses only standard
    formulas and published atomic constants, so it is fully and uniquely
    reproducible.

(B) A numerical model for Var(D), the variance of the 3D dilation generator
    D = -i(r d/dr + 3/2) evaluated on a Thomas-Fermi density profile whose
    sharp edge at r=R is smoothed over a width xi (the healing length), for
    several values of the dimensionless ratio xi/R, followed by a 5-point fit
    of Var(D) against ln(R/xi).

IMPORTANT HONESTY NOTE on part (B): the paper's prose ("a numerical
regularization (smoothed edge over scale xi) gives Var(D)*xi finite and
Var(D) growing logarithmically as xi/R -> 0; a five-point fit gives
Var(D) ~= 1.857*ln(R/xi) + 20.48") specifies the *qualitative* regularization
procedure but not the exact smoothing kernel (Fermi-function edge vs.
Gaussian-convolved edge vs. erf-edge, exact width convention, discretization,
etc.). Those choices are not otherwise recorded anywhere in the accompanying
files. This script therefore implements one clearly-stated, physically
reasonable choice (a Fermi-function-smoothed Thomas-Fermi profile) and
reports whatever fit constants that choice actually produces -- it does NOT
tune the smoothing procedure to hit 1.857/20.48. The log-divergence
structure (Var(D) ~ A*ln(R/xi) + B) is the robust, model-independent physical
content; the precise values of A and B are procedure-dependent. Any
disagreement between the coefficients found here and the paper's stated
1.857/20.48 is reported explicitly, not concealed.
"""
import numpy as np
from scipy.optimize import curve_fit

# ---------------------------------------------------------------------
# Part A: standard GPE/Thomas-Fermi parameter chain for 87Rb
# ---------------------------------------------------------------------
hbar = 1.054571817e-34       # J s
u = 1.66053906660e-27        # kg (atomic mass unit)
m_Rb87 = 86.909180527 * u    # kg, 87Rb atomic mass

n0 = 1e14 * 1e6              # peak density, 10^14 cm^-3 -> m^-3
a_s = 5.8e-9                 # s-wave scattering length, m
omega0 = 2 * np.pi * 100.0   # trap angular frequency, rad/s (100 Hz)

# Healing length: xi = 1 / sqrt(8 pi n0 a_s)   (standard result;
# equivalently xi = hbar / sqrt(2 m g n0) with g = 4 pi hbar^2 a_s / m,
# and the mass cancels exactly out of that combination).
xi0 = 1.0 / np.sqrt(8 * np.pi * n0 * a_s)

# Interaction coupling constant g = 4 pi hbar^2 a_s / m, chemical potential
# at trap center mu = g*n0 (local-density mean-field result), and the
# Thomas-Fermi radius from mu = (1/2) m omega0^2 R_TF^2.
g_int = 4 * np.pi * hbar**2 * a_s / m_Rb87
mu = g_int * n0
R_TF = np.sqrt(2 * mu / (m_Rb87 * omega0**2))

ln_R_over_xi = np.log(R_TF / xi0)
mu_in_hbar_omega0 = mu / (hbar * omega0)

print("=" * 70)
print("Part A: 87Rb Thomas-Fermi parameter chain (standard GPE formulas)")
print("=" * 70)
print(f"  healing length            xi0   = {xi0*1e6:.4f} um   (paper: 0.262 um)")
print(f"  Thomas-Fermi radius        R_TF  = {R_TF*1e6:.4f} um   (paper: 4.436 um)")
print(f"  ln(R_TF/xi0)                     = {ln_R_over_xi:.4f}      (paper: 2.83)")
print(f"  mu / (hbar*omega0)               = {mu_in_hbar_omega0:.4f}      (paper: 8.47, used in Sec.9.3)")
print()

# ---------------------------------------------------------------------
# Part B: Var(D) for a Fermi-smoothed Thomas-Fermi profile
# ---------------------------------------------------------------------
# Dimensionless units: R = 1. Profile before smoothing:
#     n_TF(r) = 1 - r^2   for r <= 1,   0 otherwise.
# Smoothed profile: the sharp bracket is convolved with a Gaussian kernel
# of width w = xi/R,
#     n(r) = [ max(1-r^2,0) * Gaussian(w) ](r)
# A convolution (rather than a one-sided Fermi taper) is used because it
# both rounds the profile off inside R and gives it a decaying tail
# extending beyond R over the healing length, which is qualitatively closer
# to how a real healed Thomas-Fermi edge behaves (the true GPE solution
# does not simply vanish at r=R; it decays smoothly over ~xi on both
# sides). Convolution of a non-negative function with a Gaussian is
# non-negative everywhere, so n(r) >= 0 automatically.
# psi(r) = sqrt(n(r)) is then used to evaluate the 3D dilation generator
# D = -i (r d/dr + 3/2) acting on a state with wavefunction psi(r)
# (spherically symmetric, so the angular integral is trivial and factors
# out of every matrix element below).
#
# For a real radial wavefunction psi(r), with measure d^3r = 4 pi r^2 dr,
# <D> = 0 by the identity used in Appendix-A-style manipulations (dilation
# generator is "off-diagonal" for a normalized real state); the numerics
# below confirm <D> ~ 0 to good precision, so Var(D) = <D^2>.
#
# D psi = -i (r psi'(r) + 1.5 psi(r))
# <D^2> = integral of |D psi|^2 * 4 pi r^2 dr   (since D is Hermitian on
#          this measure, <psi|D^2|psi> = integral |D psi|^2 dV)

def var_D(w, r_max=4.0, dr=2e-4):
    r = np.arange(dr, r_max, dr)
    N = len(r)
    bracket = np.clip(1 - r**2, 0, None)

    # Gaussian smoothing kernel of standard deviation w, on the same
    # uniform grid, applied by direct (real-space) convolution via FFT.
    kernel_half_width = min(int(8 * w / dr), N // 2 - 1)
    kx = np.arange(-kernel_half_width, kernel_half_width + 1) * dr
    kernel = np.exp(-0.5 * (kx / w) ** 2)
    kernel /= kernel.sum()
    n = np.convolve(bracket, kernel, mode="same")
    n = np.clip(n, 0, None)
    psi = np.sqrt(n)

    # normalize: integral psi^2 4 pi r^2 dr = 1
    norm = np.trapezoid(psi**2 * 4 * np.pi * r**2, r)
    psi = psi / np.sqrt(norm)

    dpsi_dr = np.gradient(psi, r)
    Dpsi_im = -(r * dpsi_dr + 1.5 * psi)   # this is i * D psi (real array); |D psi|^2 = Dpsi_im^2

    var = np.trapezoid(Dpsi_im**2 * 4 * np.pi * r**2, r)

    # <D> check (should vanish for a real state)
    mean_integrand = psi * (-(r * dpsi_dr + 1.5 * psi))
    mean = np.trapezoid(mean_integrand * 4 * np.pi * r**2, r)
    return var, mean


# Five points, geometrically spaced in xi/R, spanning a decade -- matching
# the paper's description of a "five-point fit".
w_values = np.array([0.20, 0.10, 0.05, 0.025, 0.0125])
var_values = []
mean_values = []
for w in w_values:
    v, mn = var_D(w)
    var_values.append(v)
    mean_values.append(mn)
var_values = np.array(var_values)
mean_values = np.array(mean_values)

ln_R_over_w = np.log(1.0 / w_values)


def log_model(x, A, B):
    return A * x + B


popt, _ = curve_fit(log_model, ln_R_over_w, var_values)
A_fit, B_fit = popt

print("=" * 70)
print("Part B: Var(D) regularized by a Fermi-smoothed TF edge (this script's model)")
print("=" * 70)
print(f"{'xi/R':>8}  {'ln(R/xi)':>10}  {'Var(D)':>12}  {'<D> (should be ~0)':>20}")
for w, l, v, mn in zip(w_values, ln_R_over_w, var_values, mean_values):
    print(f"{w:8.4f}  {l:10.4f}  {v:12.6f}  {mn:20.2e}")
print()
print(f"5-point fit:  Var(D) ~= {A_fit:.4f} * ln(R/xi) + {B_fit:.4f}")
print(f"Paper states: Var(D) ~= 1.857 * ln(R/xi) + 20.48")
print()

# Value at the actual 87Rb ln(R/xi) found in Part A, using this script's own fit
var_at_rb = A_fit * ln_R_over_xi + B_fit
print(f"Evaluated at this run's ln(R/xi) = {ln_R_over_xi:.4f}:")
print(f"  Var(D) [this script's fit]     = {var_at_rb:.4f}")
print(f"  Var(D) [paper's stated value]  = 25.7")
print()
print("NOTE: the log-divergence structure (Var(D) growing linearly in")
print("ln(R/xi), i.e. Var(D)*d(1/ln)... finite slope as xi/R -> 0) is")
print("reproduced. The specific slope/intercept constants are sensitive to")
print("the (unspecified) smoothing kernel and are NOT expected to match the")
print("paper's 1.857/20.48 exactly under a different, independently chosen")
print("kernel -- see module docstring.")

if __name__ == "__main__":
    import json
    results = {
        "part_A_87Rb_chain": {
            "xi0_um": float(xi0 * 1e6),
            "R_TF_um": float(R_TF * 1e6),
            "ln_R_over_xi": float(ln_R_over_xi),
            "mu_over_hbar_omega0": float(mu_in_hbar_omega0),
            "paper_states": {"xi0_um": 0.262, "R_TF_um": 4.436,
                              "ln_R_over_xi": 2.83, "mu_over_hbar_omega0": 8.47},
        },
        "part_B_VarD_fit": {
            "w_values": w_values.tolist(),
            "ln_R_over_w": ln_R_over_w.tolist(),
            "var_values": var_values.tolist(),
            "fit_A": float(A_fit),
            "fit_B": float(B_fit),
            "paper_states": {"A": 1.857, "B": 20.48, "VarD_at_Rb_params": 25.7},
            "note": "slope/intercept are smoothing-kernel-dependent; see docstring",
        },
    }
    with open("../results/results_sec9_1.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nWrote results_sec9_1.json")
