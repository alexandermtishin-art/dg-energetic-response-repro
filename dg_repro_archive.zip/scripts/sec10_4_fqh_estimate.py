"""
SUPERSEDED -- kept only as a historical record of the paper's ORIGINAL
(incorrect) approximate formula. See sec10_4_exact_cauchy_schwarz.py for
the corrected calculation used in the current version of the paper.

Why this script is wrong: the "fractional excess ~= w2/(w1*(Delta2/Delta1))"
formula below does not actually follow from the Cauchy-Schwarz inequality
chi_F >= g'(0)^2/(2W) defined in Sec. 10.3. The correct exact two-mode
formula is excess = r*(rho-1)^2/(rho+r)^2 with r=w2/w1, rho=Delta2/Delta1,
which for r=0.05, rho=30 gives ~4.66%, not ~0.17%. See
sec10_4_exact_cauchy_schwarz.py, Part 1-2, for the symbolic derivation and
an explicit check of why the approximation used here fails (it is off by
a factor of ~28x in this regime, not merely imprecise).

This script's numbers were the paper's originally published claim; it is
retained, unmodified, purely so the archive documents the error and its
correction transparently rather than silently replacing one number with
another.

Original docstring follows:
---
Reproduces the trivial arithmetic of Sec. 10.4, which is a literature
READING (from published spectral-function figures in refs [15,16]), not an
independent simulation. This script does not, and cannot, re-derive w2/w1 or
Delta2/Delta1 from first principles -- those are read off published FQH
exact-diagonalization spectral functions for a nu=2/9 state with an
artificially added three-body interaction term. The only thing "reproduced"
here is the stated order-of-magnitude arithmetic itself, so the source of
each input number is stated explicitly.
"""

w2_over_w1 = 0.05     # order-of-magnitude reading off the published spectral
                       # weight ratio for the 2nd vs 1st graviton mode,
                       # nu=2/9 + engineered 3-body term (refs [15,16])
Delta2_over_Delta1 = 30.0  # order-of-magnitude reading of the corresponding
                            # gap ratio, same source

fractional_excess = w2_over_w1 / Delta2_over_Delta1
print("Sec. 10.4: order-of-magnitude excess of chi_F over the Sec.10.3 bound")
print(f"  w2/w1 (literature reading, refs [15,16])       = {w2_over_w1}")
print(f"  Delta2/Delta1 (literature reading, refs [15,16]) = {Delta2_over_Delta1}")
print(f"  fractional excess = (w2/w1) / (Delta2/Delta1)   = {fractional_excess:.6f}")
print(f"                                                 = {fractional_excess*100:.4f}%")
print(f"  Paper states: ~= 0.05/30 ~= 0.17%")
print()
print("This arithmetic reproduces the paper's stated 0.17% exactly. It is a")
print("restatement of a literature reading, not an independent measurement or")
print("simulation; both input ratios (w2/w1, Delta2/Delta1) are sourced to")
print("refs [15,16] and are order-of-magnitude readings off a published")
print("figure, as the paper's own text states.")

# Sanity: Figure 1 / eta_chart.py's "FQH engineered 3-body" bar shows
# eta = 100.17%, i.e. chi_F exceeds the Cauchy-Schwarz bound by the
# fractional_excess computed above.
eta_engineered = 100 * (1 + fractional_excess)
print()
print(f"Corresponding Figure-1 saturation fraction: eta = 100%*(1+excess) = {eta_engineered:.2f}%")
print("Paper / eta_chart.py states: 100.17%  -- matches.")

if __name__ == "__main__":
    import json
    results = {
        "w2_over_w1": w2_over_w1,
        "Delta2_over_Delta1": Delta2_over_Delta1,
        "fractional_excess_pct": fractional_excess * 100,
        "eta_engineered_pct": eta_engineered,
        "paper_states": {"fractional_excess_pct": 0.17, "eta_engineered_pct": 100.17},
        "note": "w2/w1 and Delta2/Delta1 are literature readings (refs [15,16]), not independently computed",
    }
    with open("../results/results_sec10_4.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nWrote results_sec10_4.json")
