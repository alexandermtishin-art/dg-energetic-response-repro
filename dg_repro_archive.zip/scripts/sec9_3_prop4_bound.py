"""
Reproduces the numerical claims of Sec. 9.3 ("B3 -- Anharmonicity /
self-limitation") and the exact classical reference value it is compared
against.

Two independent pieces:

(A) EXACT, model-independent piece: the classical Thomas-Fermi
    scale-parameter equation
        b'' + omega0^2 * b = omega0^2 / b^4
    equivalent to motion in the potential
        U(b) = (omega0^2/2) b^2 + (omega0^2/3) b^-3.
    This script symbolically/analytically expands U(b) about b=1 and
    evaluates U''(1) and U'''(1) exactly (no fitting, no free parameters).

(B) DERIVED piece: Proposition 4's conditional bound 6*W*g using
    g = Var(D)/5 and W ~= mu (in units of hbar*omega0), with Var(D) and mu
    taken from sec9_1_vard_regularization.py. Because Var(D) itself is only
    as reliable as the (unspecified) smoothing procedure discussed in that
    script, this section is run BOTH with the paper's stated Var(D)=25.7
    and with this repository's own independently-computed Var(D), and both
    results are reported side by side.
"""
import numpy as np

print("=" * 70)
print("Part A: exact classical reference term from U(b)")
print("=" * 70)
# U(b) = (w0^2/2) b^2 + (w0^2/3) b^-3   (set omega0 = 1; result scales as omega0^2)
# U'(b)  =  w0^2 b - w0^2 b^-4
# U''(b) =  w0^2 + 4 w0^2 b^-5
# U'''(b) = -20 w0^2 b^-6
# At b = 1:
Upp_1 = 1.0 + 4.0     # in units of omega0^2
Uppp_1 = -20.0        # in units of omega0^2

print("U(b)  = (w0^2/2) b^2 + (w0^2/3) b^-3")
print("U'(b) =  w0^2 (b - b^-4)          -> U'(1) = 0  (equilibrium, as required)")
print("U''(b) = w0^2 (1 + 4 b^-5)        -> U''(1)  =", Upp_1, " * omega0^2  (paper: 5)")
print("U'''(b) = -20 w0^2 b^-6           -> U'''(1) =", Uppp_1, "* omega0^2  (paper: -20)")
print(f"Breathing-mode frequency sqrt(U''(1)) = sqrt({Upp_1}) = {np.sqrt(Upp_1):.6f}  (paper: sqrt(5) ~= 2.236, i.e. sqrt(5)*omega0)")
print()
print("These reproduce the paper's stated U''(1)=5*omega0^2 and U'''(1)=-20*omega0^2")
print("exactly -- this is pure calculus on a stated classical ODE, with no")
print("free parameters, so it is not subject to any modeling ambiguity.")
print()

print("=" * 70)
print("Part B: Proposition 4 bound 6*W*g, using two different Var(D) inputs")
print("=" * 70)

mu_over_hbar_omega0 = 8.4766   # from sec9_1_vard_regularization.py, Part A (87Rb chain)

for label, VarD in [("paper's stated Var(D)", 25.7),
                     ("this archive's independently computed Var(D)", 5.4680)]:
    g = VarD / 5.0
    W = mu_over_hbar_omega0
    bound_6Wg = 6 * W * g
    classical_term = abs(Uppp_1)  # = 20, in units of hbar*omega0 per the paper's convention
    eta = classical_term / bound_6Wg * 100
    print(f"-- using {label} (Var(D) = {VarD}) --")
    print(f"   g = Var(D)/5                 = {g:.4f}   (1/(hbar*omega0)^2)")
    print(f"   W ~= mu                      = {W:.4f}   (hbar*omega0)")
    print(f"   bound 6*W*g                  = {bound_6Wg:.2f}  hbar*omega0")
    print(f"   exact classical |U'''(1)|    = {classical_term:.1f}  hbar*omega0")
    print(f"   ratio bound/classical        = {bound_6Wg/classical_term:.2f}x")
    print(f"   saturation fraction eta = classical/bound = {eta:.2f}%")
    print()

print("Paper states: bound 6*W*g ~= 261 hbar*omega0 (~13x the classical term,")
print("i.e. eta ~= 7.7%, the value plotted in Figure 1 / eta_chart.png).")
print()
print("CONCLUSION: with the paper's own stated Var(D)=25.7 as input, this")
print("script exactly reproduces bound ~=261, ratio ~=13x, and eta~=7.7% --")
print("the ALGEBRA of Sec. 9.3 (and the qualitative conclusion 'bound not")
print("saturated, channel closed by measurement-level degeneracy, not by a")
print("vanishing bound') is fully independent of the exact Var(D) input:")
print("under this archive's own from-scratch Var(D)~=5.47, the bound is")
print("still ~=55 hbar*omega0, still several times larger than the known")
print("classical term (~2.7x rather than ~13x), so the qualitative B3")
print("verdict of Sec. 9.3 is robust to the Var(D) discrepancy flagged in")
print("sec9_1_vard_regularization.py. Only the specific headroom multiple")
print("(13x vs 2.7x) and the exact eta value plotted in Figure 1 (7.7% vs")
print("~36%) depend on the un-reproduced smoothing procedure.")

print()
print("=" * 70)
print("Part C: Sec. 10.3 Cauchy-Schwarz inequality chi_F >= g'(0)^2/(2W),")
print("        verified numerically on random multi-channel examples")
print("=" * 70)
print("chi_F = 2 sum_n w_n/Delta_n^2,  g'(0) = 2 sum_n w_n/Delta_n,  W = sum_n w_n")
print("Cauchy-Schwarz: (sum_n w_n/Delta_n)^2 <= (sum_n w_n) * (sum_n w_n/Delta_n^2)")
print("                 => g'(0)^2/4 <= W * chi_F/2  <=>  chi_F >= g'(0)^2/(2W)")
print("Equality iff w_n/Delta_n is proportional to w_n, i.e. all active Delta_n equal.")
print()

rng = np.random.default_rng(20260930)
n_trials = 100000
worst_margin = np.inf
worst_case = None
saturating_checks = []

for trial in range(n_trials):
    n_channels = rng.integers(1, 8)
    w = rng.uniform(0.01, 5.0, size=n_channels)
    Delta = rng.uniform(0.1, 10.0, size=n_channels)
    chi_F = 2 * np.sum(w / Delta**2)
    gprime = 2 * np.sum(w / Delta)
    W = np.sum(w)
    bound = gprime**2 / (2 * W)
    margin = chi_F - bound
    if margin < worst_margin:
        worst_margin = margin
        worst_case = (w.copy(), Delta.copy())

print(f"Random multi-channel Cauchy-Schwarz check: {n_trials} trials,")
print(f"1-7 active channels, w ~ U(0.01,5), Delta ~ U(0.1,10) per channel.")
print(f"Smallest margin chi_F - bound observed: {worst_margin:.3e}  (must be >= 0)")
print("No violation found, consistent with the paper's claim.")
print()

# Explicit single-channel and degenerate-gap saturation checks
w1 = np.array([1.7])
D1 = np.array([3.2])
chi_F1 = 2 * np.sum(w1 / D1**2)
bound1 = (2 * np.sum(w1 / D1))**2 / (2 * np.sum(w1))
print(f"Single-channel case: chi_F={chi_F1:.6f}, bound={bound1:.6f}, "
      f"|chi_F-bound|={abs(chi_F1-bound1):.2e}  (should be ~0, exact saturation)")

w2 = rng.uniform(0.1, 5.0, size=5)
D2 = np.full(5, 2.5)  # degenerate gaps
chi_F2 = 2 * np.sum(w2 / D2**2)
bound2 = (2 * np.sum(w2 / D2))**2 / (2 * np.sum(w2))
print(f"Degenerate-gap case (5 channels, all Delta=2.5): chi_F={chi_F2:.6f}, "
      f"bound={bound2:.6f}, |chi_F-bound|={abs(chi_F2-bound2):.2e}  (should be ~0)")
print()
print("Both saturation limits (single active channel; degenerate gaps) confirmed")
print("to machine precision, matching the paper's statement that equality holds")
print("iff every state contributing non-zero weight shares a common gap.")

if __name__ == "__main__":
    import json
    results = {
        "part_A_classical_term": {
            "Upp_1_over_omega0sq": Upp_1,
            "Uppp_1_over_omega0sq": Uppp_1,
            "paper_states": {"Upp_1": 5, "Uppp_1": -20},
        },
        "part_B_prop4_bound": {
            "mu_over_hbar_omega0": mu_over_hbar_omega0,
            "using_paper_VarD_25p7": {
                "g": 25.7 / 5, "bound_6Wg": 6 * mu_over_hbar_omega0 * (25.7 / 5),
            },
            "using_this_archive_VarD_5p468": {
                "g": 5.4680 / 5, "bound_6Wg": 6 * mu_over_hbar_omega0 * (5.4680 / 5),
            },
            "paper_states": {"bound_6Wg": 261, "classical_term": 20, "ratio": 13, "eta_pct": 7.7},
        },
        "part_C_sec10_3_cauchy_schwarz": {
            "n_trials": n_trials,
            "worst_margin_chi_F_minus_bound": float(worst_margin),
            "single_channel_saturation_error": float(abs(chi_F1 - bound1)),
            "degenerate_gap_saturation_error": float(abs(chi_F2 - bound2)),
        },
    }
    with open("../results/results_sec9_3.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nWrote results_sec9_3.json")
