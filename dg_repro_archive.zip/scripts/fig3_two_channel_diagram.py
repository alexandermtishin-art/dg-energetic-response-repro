"""
Figure 3: block diagram of the two-channel FQH protocol of Sec. 12.1-12.3.
Channel 1 (RILS, optical) and Channel 2 (transport/dissipation) are
physically distinct detection chains measured at the same kappa, feeding
into the differential observable D(kappa) of Sec. 12.3, referenced against
an interleaved Laughlin companion filling. Sec. 12.2's identifiability
criterion requires that no single uncalibrated instrumental factor act on
both channels with the same weight; the diagram makes the separation of
detection chains, and the independence of the absolute cross-normalization
reference from the Laughlin differential test (Sec. 12.2/12.3, as amended),
visually explicit.

Purely illustrative -- no new claim, only a picture of the protocol already
specified in the text.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

plt.rcParams["font.family"] = "Liberation Serif"
plt.rcParams["font.size"] = 11

color_ch1 = "#2a78d6"   # blue -- Channel 1
color_ch2 = "#eb6834"   # orange -- Channel 2
color_out = "#4a4a4a"   # neutral dark grey -- shared output / comparison

fig, ax = plt.subplots(figsize=(7.4, 4.6), dpi=200)


def box(x, y, w, h, text, color, fontsize=9.6, lw=1.6, fc_alpha=0.10):
    b = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.06",
                        linewidth=lw, edgecolor=color, facecolor=color, alpha=fc_alpha, zorder=1)
    ax.add_patch(b)
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fontsize,
            color="black", zorder=2, wrap=True)
    return (x, y, w, h)


def arrow(b1, b2, color="black"):
    x1 = b1[0] + b1[2]
    y1 = b1[1] + b1[3] / 2
    x2 = b2[0]
    y2 = b2[1] + b2[3] / 2
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=13,
                                  linewidth=1.4, color=color, zorder=1))


# Channel 1 row (top)
c1a = box(0.0, 3.0, 1.85, 0.8, "Same κ\n(displacement field,\ndensity)", "black", fc_alpha=0.0)
c1b = box(2.1, 3.0, 1.9, 0.8, "Channel 1: RILS\n(optical, polarization-\nresolved) [13]", color_ch1)
c1c = box(4.25, 3.0, 1.9, 0.8, r"Extract $\Delta_n$(κ), $w_n$(κ)" + "\n→ g′(0)(κ), W(κ)", color_ch1)
c1d = box(6.4, 3.0, 1.75, 0.8, "b(κ) =\ng′(0)²/(2W)\n(§10.3)", color_ch1)
arrow(c1a, c1b, color_ch1)
arrow(c1b, c1c, color_ch1)
arrow(c1c, c1d, color_ch1)

# Channel 2 row (bottom)
c2a = box(0.0, 1.1, 1.85, 0.8, "Same κ\n(displacement field,\ndensity)", "black", fc_alpha=0.0)
c2b = box(2.1, 1.1, 1.9, 0.8, "Channel 2: ps ramp,\nτ≈15–22 ps, read via\ntransport/dissipation", color_ch2)
c2c = box(4.25, 1.1, 1.9, 0.8, r"Measure $P_{exc}(\tau)$" + "\n(distinct detection\nchain from Ch. 1)", color_ch2)
c2d = box(6.4, 1.1, 1.75, 0.8, r"$\chi_F(\kappa)$" + "\n(§12.1, §12.5\nfallback fit)", color_ch2)
arrow(c2a, c2b, color_ch2)
arrow(c2b, c2c, color_ch2)
arrow(c2c, c2d, color_ch2)

# Convergence into the differential observable
c_out = box(3.1, -0.85, 3.2, 0.95,
            r"$D(\kappa){=}[\chi_F(\kappa){-}b(\kappa)]_{\mathrm{target}}{-}[\chi_F(\kappa){-}b(\kappa)]_{\mathrm{Laughlin}}$"
            + "\ninterleaved vs. companion ν=1/3 filling (§12.3)",
            color_out, fontsize=9.4)
# manual converging arrows into c_out
ax.add_patch(FancyArrowPatch((c1d[0] + c1d[2] / 2, c1d[1]), (c_out[0] + c_out[2] * 0.72, c_out[1] + c_out[3]),
                              arrowstyle="-|>", mutation_scale=13, linewidth=1.4, color=color_ch1,
                              connectionstyle="arc3,rad=-0.15", zorder=1))
ax.add_patch(FancyArrowPatch((c2d[0] + c2d[2] / 2, c2d[1]), (c_out[0] + c_out[2] * 0.72, c_out[1] + c_out[3]),
                              arrowstyle="-|>", mutation_scale=13, linewidth=1.4, color=color_ch2,
                              connectionstyle="arc3,rad=0.15", zorder=1))

ax.text(3.9, 2.15,
        "No single uncalibrated instrumental factor can act on both channels with the\n"
        "same weight (§12.2 identifiability criterion) — the two chains are physically distinct.",
        ha="center", fontsize=8.6, style="italic", color="#333333")

ax.text(6.85, -1.55,
        "Absolute cross-normalization between channels (§12.2) uses an\n"
        "independent reference (e.g. a cyclotron-resonance line) — never the\n"
        "Laughlin filling above, which is reserved for the differential test alone.",
        ha="center", fontsize=8.3, style="italic", color="#333333")

ax.set_xlim(-0.3, 8.3)
ax.set_ylim(-2.3, 4.1)
ax.axis("off")
ax.set_title("Two physically distinct channels feeding one differential test (§12.1–12.3)",
              fontsize=11, pad=10)

plt.tight_layout()
plt.savefig("../figures/two_channel_diagram.png", dpi=200, bbox_inches="tight")
print("Wrote ../figures/two_channel_diagram.png")
