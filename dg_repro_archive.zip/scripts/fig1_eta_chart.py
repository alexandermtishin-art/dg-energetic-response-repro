import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

plt.rcParams["font.family"] = "Liberation Serif"
plt.rcParams["font.size"] = 11

# (label, eta_percent (single value) OR (low, high) range, bound_type)
# bound_type: "upper" = Prop.4 upper ceiling (headroom = unused capacity)
#             "lower" = Cauchy-Schwarz lower bound (saturation = degeneracy, no independent content)
#             "open"  = Cauchy-Schwarz LOWER bound, but exceeded well beyond
#                       what any degeneracy/engineering argument in this
#                       paper closes -- the one open channel (§10.4-10.5)
#
# The BEC anharmonicity entry is drawn as a RANGE, not a point estimate: the
# reproducibility archive found that Var(D) (and hence this eta value)
# depends on an edge-regularization kernel not fully pinned down by the
# analytic argument, spanning eta ~= 7.7%-36% across the kernels checked
# there. See the reproducibility archive / Sec. 9.1, 9.3 for details.
#
# The engineered-nu=2/9 value is CORRECTED from an earlier order-of-magnitude
# estimate (w2/(w1*Delta2/Delta1) ~= 0.17%) to the exact two-mode
# Cauchy-Schwarz excess formula derived in Sec. 10.3 (~4.66%, see
# reproducibility archive, sec10_4_exact_cauchy_schwarz.py).
#
# The realistic nu=2/7 (lowest LL, ordinary Coulomb interaction, NOT
# engineered) entry is NEW: it combines the exact spectral-weight ratio
# w2/w1=0.757 computed from Wang & Yang (Nat. Commun. 14, 2317, 2023)
# Source Data with the gap ratio Delta2/Delta1~=2.8 measured directly by
# Yang et al. (Nature Physics 22, 1230, 2026). This is the one channel in
# the whole paper not closed by any argument used elsewhere.
data = [
    ("BEC anharmonicity\n(Prop. 4, §9.3)", (7.7, 36.0), "upper"),
    ("FQH, Laughlin states\n(§10.4)", 100.0, "lower"),
    ("FQH, SLL near-degenerate\nJain ν=2/7 (§10.4)", 100.0, "lower"),
    ("FQH, engineered ν=2/9\n3-body (§10.4)", 104.66, "lower"),
    ("FQH, realistic LLL ν=2/7\n— OPEN (§10.4–10.5)", 119.4, "open"),
    ("TBG, geometric weight\n(§13)", 100.0, "lower"),
]

labels = [d[0] for d in data]
kinds = [d[2] for d in data]

color_upper = "#2a78d6"  # blue — categorical slot 1 (validated, dataviz skill)
color_lower = "#eb6834"  # orange — categorical slot 2 (validated adjacent pair, ΔE 24.7 CVD / 33.6 normal)
color_open = "#c62828"   # red — the one open channel, deliberately distinct from both closed types
color_map = {"upper": color_upper, "lower": color_lower, "open": color_open}
colors = [color_map[k] for k in kinds]

fig, ax = plt.subplots(figsize=(7.2, 4.2), dpi=200)

y_pos = range(len(labels))

# Draw each bar: a plain bar for a single value, a floating range-bar for a
# (low, high) tuple.
bar_height = 0.55
for i, d in enumerate(data):
    val = d[1]
    if isinstance(val, tuple):
        low, high = val
        ax.barh(i, high - low, left=low, color=colors[i], edgecolor="black",
                 linewidth=0.8, height=bar_height)
    else:
        ax.barh(i, val, color=colors[i], edgecolor="black", linewidth=0.8, height=bar_height)

ax.axvline(100, color="black", linewidth=1.0, linestyle="--")
ax.text(100, -0.75, "own theoretical bound = 100%", ha="center", va="bottom", fontsize=9)

for i, d in enumerate(data):
    val = d[1]
    if isinstance(val, tuple):
        low, high = val
        label = f"{low:.1f}–{high:.1f}%"
        ax.text(high + 2, i, label, va="center", ha="left", fontsize=10)
    else:
        label = f"{val:.1f}%" if val != 100.0 else "100%"
        if val <= 30:
            ax.text(val + 2, i, label, va="center", ha="left", fontsize=10)
        else:
            ax.text(val - 3, i, label, va="center", ha="right", fontsize=10, color="white")

ax.set_yticks(list(y_pos))
ax.set_yticklabels(labels, fontsize=10)
ax.invert_yaxis()
ax.set_ylim(len(labels) - 0.4, -1.1)
ax.set_xlim(0, 132)
ax.set_xlabel(r"$\eta$ — fraction of each channel's own theoretical bound reached (%)", fontsize=10)
ax.set_title("Saturation fraction $\\eta$ across the channels computed in Part II", fontsize=11, pad=12)

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

legend_handles = [
    plt.Rectangle((0, 0), 1, 1, facecolor=color_upper, edgecolor="black", linewidth=0.8),
    plt.Rectangle((0, 0), 1, 1, facecolor=color_lower, edgecolor="black", linewidth=0.8),
    plt.Rectangle((0, 0), 1, 1, facecolor=color_open, edgecolor="black", linewidth=0.8),
]
ax.legend(
    legend_handles,
    ["Upper-bound type (Prop. 4): distance below 100% is unused response capacity\n(BEC bar spans the range found across edge-regularization kernels, §9.1/App.)",
     "Lower-bound type (Cauchy–Schwarz, Prop. 3), closed: value at 100% signals redundancy",
     "Lower-bound type, OPEN (§10.4–10.5): value exceeds 100% by more than any\ndegeneracy/engineering argument in this paper closes — not yet measured directly"],
    loc="upper center", bbox_to_anchor=(0.5, -0.26), fontsize=8.3, frameon=False, ncol=1
)

plt.tight_layout()
plt.savefig("../figures/eta_chart.png",
            dpi=200, bbox_inches="tight")
print("Wrote ../figures/eta_chart.png")
