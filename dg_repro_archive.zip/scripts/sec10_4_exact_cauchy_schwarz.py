"""
Sec. 10.3/10.4 -- EXACT two-mode Cauchy-Schwarz excess formula, replacing the
paper's earlier order-of-magnitude approximation w2/(w1*(Delta2/Delta1)).

Background
----------
Sec. 10.3 defines (standard second-order perturbation theory):
    g'(0)  = 2 * sum_n  w_n / Delta_n
    chi_F  = 2 * sum_n  w_n / Delta_n^2
    W      =     sum_n  w_n            (total quadrupole sum rule)
and states the Cauchy-Schwarz inequality
    chi_F >= g'(0)^2 / (2W)                                        (*)
with equality iff all Delta_n sharing non-zero weight are equal.

For a two-mode spectral function (w1, Delta1) and (w2, Delta2), this script:
  1. Derives, symbolically (sympy), the EXACT fractional excess
         excess(r, rho) = chi_F / bound - 1
     as a closed-form function of r = w2/w1 and rho = Delta2/Delta1, and
     confirms it reduces to 0 at rho=1 and at r=0 (both required by the
     equality condition stated in the paper).
  2. Shows this exact formula does NOT reduce to the paper's stated
     approximation "excess ~= r/rho" -- that approximation is checked
     against the exact formula and found to be wrong by more than an
     order of magnitude in the regime the paper itself uses it in.
  3. Recomputes the Sec. 10.4 "engineered nu=2/9, three-body term" case
     with the CORRECT exact formula, using the same literature-read inputs
     (w2/w1~=0.05, Delta2/Delta1~=30, refs [15,16]) the paper already cites.
  4. Computes the fractional excess for the *realistic* (non-engineered)
     nu=2/7, Coulomb, lowest-Landau-level case, combining:
       - w2/w1, computed EXACTLY (not read off a plot) from the published
         Source Data of Wang & Yang, Nat. Commun. 14, 2317 (2023)
         [ref [16] in the paper], Fig. 3a, N=8 electrons, Coulomb
         interaction -- see data/wang_yang_2023_fig3a_nu2-7_8e_coulomb.csv,
         a direct copy of the journal's own Source Data file.
       - Delta2/Delta1, taken from the real experimental measurement of
         Yang, Wang, Lu, Liu, Baldwin, West, Pfeiffer, Yang, Balram, Du,
         "Emergent partons in fractional quantum Hall systems,"
         Nature Physics 22, 1230 (2026): Delta_L^0 ~= 0.015 Ec,
         Delta_H^0 ~= 0.042 Ec at nu=2/7 (lowest LL), ratio ~= 2.8.

Caveats stated explicitly (do not remove):
  - The N=8-electron spherical-geometry weight ratio is a finite-size
    quantity; the thermodynamic-limit value could differ (the authors
    themselves report consistent high-overlap trends at this system size
    for the SAME state, which is the best available evidence of stability,
    but this is not a claim of an exact thermodynamic-limit value).
  - Combining a finite-size THEORY weight ratio with a real EXPERIMENTAL
    gap ratio is an approximation, not a single self-consistent
    calculation; both numbers describe the same physical case (realistic
    Coulomb interaction, nu=2/7, lowest Landau level), which is the
    justification for combining them.
"""
import csv
import json
import os

import sympy as sp

# ---------------------------------------------------------------------
# Part 1: symbolic derivation of the exact two-mode excess formula
# ---------------------------------------------------------------------
w1, w2, D1, D2, r, rho = sp.symbols("w1 w2 D1 D2 r rho", positive=True)

A = w1 / D1 + w2 / D2         # = g'(0)/2
B = w1 / D1**2 + w2 / D2**2   # = chi_F/2
W = w1 + w2

chi_F = 2 * B
bound = (2 * A) ** 2 / (2 * W)   # g'(0)^2 / (2W)

excess_raw = sp.simplify(chi_F / bound - 1)
excess_r_rho = sp.simplify(excess_raw.subs({w2: r * w1, D2: rho * D1}))
excess_closed = sp.factor(excess_r_rho)

print("=" * 74)
print("Part 1: exact two-mode Cauchy-Schwarz excess formula")
print("=" * 74)
print("chi_F/bound - 1, in terms of w1,w2,D1,D2:")
print(" ", excess_raw)
print()
print("Substituting r=w2/w1, rho=D2/D1:")
print(" ", excess_r_rho)
print()

# Closed form, verified by hand: r*(rho-1)^2 / (rho+r)^2
excess_formula = r * (rho - 1) ** 2 / (rho + r) ** 2
check = sp.simplify(excess_r_rho - excess_formula)
assert check == 0, f"closed-form check failed, residual={check}"
print("Closed form:  excess(r, rho) = r*(rho-1)^2 / (rho+r)^2")
print("  (verified symbolically identical to the direct substitution above)")
print()

# Sanity checks required by the paper's own equality condition
assert sp.simplify(excess_formula.subs(rho, 1)) == 0
assert sp.simplify(excess_formula.subs(r, 0)) == 0
print("Sanity checks: excess(r,1)=0 and excess(0,rho)=0 -- both hold,")
print("consistent with the paper's stated equality condition (equal gaps,")
print("or a single dominant mode).")
print()


def excess_exact(r_val, rho_val):
    return float(excess_formula.subs({r: sp.nsimplify(r_val), rho: sp.nsimplify(rho_val)}))


def excess_paper_approx(r_val, rho_val):
    """The paper's ORIGINAL approximate formula, w2/(w1*Delta2/Delta1) = r/rho."""
    return r_val / rho_val


# ---------------------------------------------------------------------
# Part 2: the paper's approximation is checked against the exact formula
# ---------------------------------------------------------------------
print("=" * 74)
print("Part 2: is the paper's 'excess ~= r/rho' approximation valid?")
print("=" * 74)
r_test, rho_test = 0.05, 30.0
exact_val = excess_exact(r_test, rho_test)
approx_val = excess_paper_approx(r_test, rho_test)
print(f"  at r={r_test}, rho={rho_test} (the paper's own engineered-case numbers):")
print(f"    exact excess   = {exact_val*100:.4f}%")
print(f"    r/rho approx   = {approx_val*100:.4f}%")
print(f"    ratio exact/approx = {exact_val/approx_val:.1f}x")
print()
print("  The approximation is NOT the correct small-r limit of the exact")
print("  formula. Expanding excess(r,rho) to linear order in r at fixed rho:")
series = sp.series(excess_formula, r, 0, 2).removeO()
print("   ", sp.simplify(series), " (leading term is 'r', not 'r/rho')")
print()
print("  This is a derivation error in the paper's original Sec. 10.4 text,")
print("  independent of any new experimental input: the correct fractional")
print("  excess for the ENGINEERED nu=2/9 case (same literature-read inputs,")
print(f"  refs [15,16]) is {exact_val*100:.2f}%, not the previously stated 0.17%.")
print()

# ---------------------------------------------------------------------
# Part 3: realistic (non-engineered) nu=2/7, lowest-LL Coulomb case
# ---------------------------------------------------------------------
print("=" * 74)
print("Part 3: realistic nu=2/7, lowest-LL, Coulomb interaction")
print("=" * 74)

data_path = os.path.join(os.path.dirname(__file__), "..", "data",
                          "wang_yang_2023_fig3a_nu2-7_8e_coulomb.csv")
with open(data_path, newline="") as f:
    rows = list(csv.reader(f))
header, rows = rows[0], rows[1:]
E_vals = [float(row[0]) for row in rows]
I_vals = [float(row[1]) for row in rows]

# Two well-separated clusters, identified by inspection of the spectral
# function (see paper Fig. 3a caption: "A graviton peak can be distinguished
# by a bunch of adjacent non-zero stems within a specific sub-Hilbert
# space"). Boundaries chosen at the near-zero gap between clusters.
low = [(e, i) for e, i in zip(E_vals, I_vals) if e < 2.90]
high = [(e, i) for e, i in zip(E_vals, I_vals) if 2.90 <= e < 2.935]
tail = [(e, i) for e, i in zip(E_vals, I_vals) if e >= 2.935]

w_low = sum(i for _, i in low)
w_high = sum(i for _, i in high)
w_tail = sum(i for _, i in tail)
total = w_low + w_high + w_tail

print(f"  Source Data: Wang & Yang, Nat. Commun. 14, 2317 (2023), Fig. 3a,")
print(f"  N=8 electrons, Coulomb interaction, nu=2/7 (lowest LL).")
print(f"  Sum rule check: total weight = {total:.6f} (should be ~1)")
print(f"    low-energy peak  (primary CF graviton):  w1 = {w_low:.4f}")
print(f"    high-energy peak (parton graviton):       w2 = {w_high:.4f}")
print(f"    residual tail/continuum:                       {w_tail:.4f}")
r_realistic = w_high / w_low
print(f"    w2/w1 = {r_realistic:.4f}")
print()

# Gap ratio: taken from the real experimental measurement (Du et al. 2026),
# not from this finite-size ED dataset (which lacks the ground-state energy
# needed to convert absolute E values into gaps).
rho_realistic = 0.042 / 0.015  # Delta_H^0 / Delta_L^0, Yang et al. Nat. Phys. 2026
print(f"  Delta2/Delta1 = 0.042/0.015 = {rho_realistic:.3f}")
print(f"    (Yang, Wang, Lu, Liu, Baldwin, West, Pfeiffer, Yang, Balram, Du,")
print(f"     Nature Physics 22, 1230 (2026), nu=2/7, lowest LL, sample A)")
print()

exact_realistic = excess_exact(r_realistic, rho_realistic)
approx_realistic = excess_paper_approx(r_realistic, rho_realistic)
print(f"  Exact fractional excess  = {exact_realistic*100:.2f}%")
print(f"  (crude r/rho approx would give {approx_realistic*100:.2f}%, for comparison only)")
print()
print("  This is the headline result: a fully realistic, already")
print("  experimentally realized FQH platform (ordinary GaAs 2DEG, nu=2/7,")
print("  Coulomb interaction, lowest Landau level -- no engineering)")
print(f"  gives a fractional excess of order {exact_realistic*100:.0f}%, roughly two orders")
print("  of magnitude larger than the paper's previous 'engineered-only,")
print("  sub-percent' figure, and not small.")

eta_realistic = 100 * (1 + exact_realistic)
eta_engineered_corrected = 100 * (1 + exact_val)

if __name__ == "__main__":
    results = {
        "exact_formula": "excess(r,rho) = r*(rho-1)**2/(rho+r)**2, r=w2/w1, rho=Delta2/Delta1",
        "engineered_nu2_9_case": {
            "r": r_test, "rho": rho_test,
            "exact_excess_pct": exact_val * 100,
            "paper_original_approx_pct": approx_val * 100,
            "paper_original_stated_pct": 0.17,
            "eta_pct": eta_engineered_corrected,
        },
        "realistic_nu2_7_LLL_Coulomb_case": {
            "w_low": w_low, "w_high": w_high, "w_tail_residual": w_tail,
            "r_w2_over_w1": r_realistic,
            "rho_gap_ratio_from_experiment": rho_realistic,
            "exact_excess_pct": exact_realistic * 100,
            "crude_approx_pct": approx_realistic * 100,
            "eta_pct": eta_realistic,
            "sources": {
                "weights": "Wang & Yang, Nat. Commun. 14, 2317 (2023), Fig. 3a Source Data",
                "gaps": "Yang et al., Nature Physics 22, 1230 (2026), Fig. 3d / main text",
            },
        },
        "note": "Supersedes sec10_4_fqh_estimate.py's approximate-formula result.",
    }
    out_dir = os.path.join(os.path.dirname(__file__), "..", "results")
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "results_sec10_4_exact.json"), "w") as f:
        json.dump(results, f, indent=2)
    print("\nWrote results_sec10_4_exact.json")
