"""
Reproduces the numerical claims of Appendix B ("Elimination of Measurement
Nuisance Parameters"), the worked illustration of the profiled Fisher
information I_eff = ||(I - P_Btilde) s_tilde||^2 of Eq. (20) / Sec. 6.

Setup, fully specified by the paper's own text: 41 equally spaced
dimensionless points in [0,1] (x_i = i/40, i=0..40), unit noise covariance
(so no whitening is needed, s_tilde = s, B_tilde = B). Two candidate
"signals" are tested:
  - a linear signal, s = x
  - a quadratic signal, s = x^2
against nuisance bases of increasing size:
  - offset only:            B = [1]
  - offset + slope:         B = [1, x]
  - offset + slope + quad.: B = [1, x, x^2]
"""
import numpy as np

N = 41
x = np.linspace(0.0, 1.0, N)  # 41 equally spaced points in [0,1]


def profiled_info(s, B_cols):
    """I_eff = s^T s - s^T B (B^T B)^-1 B^T s , for unit covariance."""
    B = np.column_stack(B_cols)
    P = B @ np.linalg.pinv(B.T @ B) @ B.T
    resid = s - P @ s
    return float(resid @ resid)


ones = np.ones(N)

print("=" * 70)
print("Appendix B: profiled Fisher information, 41-point grid on [0,1]")
print("=" * 70)

s_lin = x
I_offset_only = profiled_info(s_lin, [ones])
I_offset_slope = profiled_info(s_lin, [ones, x])
print(f"Linear signal (s=x):")
print(f"  info vs. offset only          = {I_offset_only:.10f}   (paper: 3.5875)")
print(f"  info vs. offset + slope       = {I_offset_slope:.3e}   (paper: 'reduces to numerical zero')")
print()

s_quad = x ** 2
I_off_slope_quad_signal = profiled_info(s_quad, [ones, x])
I_off_slope_quadfree = profiled_info(s_quad, [ones, x, x ** 2])
print(f"Quadratic signal (s=x^2):")
print(f"  info vs. offset + slope       = {I_off_slope_quad_signal:.10f}   (paper: 0.2506765625)")
print(f"  info vs. offset+slope+quad.   = {I_off_slope_quadfree:.3e}   (paper: 'degenerate' / numerical zero)")
print()
print("All four figures match the paper's stated values (the two 'numerical")
print("zero' cases match to floating-point precision, exactly as the text")
print("implies -- a signal that lies exactly in the nuisance span carries")
print("zero information, up to roundoff).")

if __name__ == "__main__":
    import json
    results = {
        "linear_signal_info_offset_only": I_offset_only,
        "linear_signal_info_offset_slope": I_offset_slope,
        "quadratic_signal_info_offset_slope": I_off_slope_quad_signal,
        "quadratic_signal_info_offset_slope_quad": I_off_slope_quadfree,
        "paper_states": {
            "linear_offset_only": 3.5875,
            "linear_offset_slope": "numerical zero",
            "quadratic_offset_slope": 0.2506765625,
            "quadratic_offset_slope_quad": "degenerate / numerical zero",
        },
    }
    with open("../results/results_appendixB.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nWrote results_appendixB.json")
